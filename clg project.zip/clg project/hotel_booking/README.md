# Hotel Room Booking Web Application

A complete hotel room booking system built with Flask (Python), HTML, and CSS. Features user authentication, room management, booking system, and admin panel.

## Features

### User System
- User registration and login
- Secure password hashing
- User dashboard with booking history

### Room Management
- Display all available rooms
- Room details page with amenities
- Admin panel for room management (add, edit, delete)

### Booking System
- Real-time room availability checking
- Date selection with conflict prevention
- Automatic cost calculation
- Booking history tracking

### Admin Panel
- Admin authentication
- Room CRUD operations
- Booking overview and management
- Revenue and booking statistics

## Tech Stack

- **Backend**: Python Flask
- **Frontend**: HTML + CSS (no JavaScript frameworks)
- **Database**: JSON files (users.json, rooms.json, bookings.json)
- **Authentication**: Flask sessions with password hashing

## Installation & Setup

1. **Clone or download the project files**

2. **Install Python dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the application**:
   **Option A - Double-click run.bat (Easiest)**:
   - Double-click on `run.bat` file in the hotel_booking folder
   - **Browser will automatically open** to `http://127.0.0.1:5000`

   **Option B - From VS Code (Recommended)**:
   - Open the `hotel_booking` folder in VS Code
   - Press `F5` to start debugging
   - **Browser will automatically open** to `http://127.0.0.1:5000`

   **Option C - From Terminal**:
   ```bash
   python app.py
   ```
   Browser will automatically open to: `http://127.0.0.1:5000`

## Project Structure

```
hotel_booking/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── README.md             # This file
├── templates/            # HTML templates
│   ├── base.html
│   ├── index.html
│   ├── register.html
│   ├── login.html
│   ├── room_details.html
│   ├── booking.html
│   ├── user_dashboard.html
│   ├── admin_dashboard.html
│   ├── admin_add_room.html
│   ├── admin_edit_room.html
│   └── admin_all_bookings.html
├── static/              # CSS and static files
│   └── style.css
└── data/                # JSON data files
    ├── users.json
    ├── rooms.json
    └── bookings.json
```

## How to Use

### For Users

1. **Register**: Create a new account with name, email, and password
2. **Login**: Log in with your credentials
3. **Browse Rooms**: View all available rooms on the homepage
4. **View Details**: Click on any room to see detailed information
5. **Book Room**: Select check-in and check-out dates to make a booking
6. **View Bookings**: Check your booking history in the dashboard

### For Admins

1. **First User**: The first registered user becomes the admin automatically
2. **Add Rooms**: Use the admin panel to add new rooms with details
3. **Manage Rooms**: Edit or delete existing rooms
4. **View Bookings**: See all bookings made by users
5. **Statistics**: View booking and revenue statistics

## Sample Data

The application comes with 6 sample rooms:
- Standard rooms (₹1500/night)
- Deluxe rooms (₹2500-2800/night)  
- Premium Suite (₹4500/night)
- Executive Suite (₹6500/night)

## Security Features

- Password hashing using Werkzeug
- Session-based authentication
- Admin route protection
- Input validation and sanitization
- SQL injection protection (no SQL used)

## Key Features

- **No Database Required**: Uses JSON files for data storage
- **Responsive Design**: Works on desktop and mobile devices
- **Real-time Booking**: Prevents double-booking with date conflict checking
- **Cost Calculation**: Automatic total cost calculation based on stay duration
- **Admin Panel**: Complete room and booking management

## Troubleshooting

### Common Issues

1. **Port Already in Use**: Change the port in `app.run(debug=True, port=5001)`
2. **Permission Errors**: Make sure you have write permissions for the data directory
3. **Missing Dependencies**: Run `pip install -r requirements.txt`

### Reset Data

To reset the application data:
1. Delete the contents of the `data/` directory
2. Restart the application (it will create empty JSON files)

## Browser Compatibility

The application works with:
- Chrome (recommended)
- Firefox
- Safari
- Edge

## License

This project is open source and available under the MIT License.
