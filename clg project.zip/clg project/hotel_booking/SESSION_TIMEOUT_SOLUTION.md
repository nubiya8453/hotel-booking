# Session Timeout Solution for Hotel Booking Application

## Problem Description

The user reported that after 1 week or after many days, the application was not showing output and was displaying a retry button instead. This issue was caused by Flask session timeouts.

## Root Cause Analysis

1. **Default Flask Session Behavior**: Flask sessions have a default timeout mechanism
2. **No Session Management**: The application didn't have explicit session timeout configuration
3. **Poor Error Handling**: When sessions expired, users weren't properly notified or redirected
4. **Lost Booking Data**: Users in the middle of booking processes lost their progress

## Solution Implemented

### 1. Session Configuration

Added explicit session timeout configuration in both `app.py` and `enhanced_app.py`:

```python
# Session configuration
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=24)  # 24 hour session timeout
app.config['SESSION_COOKIE_SECURE'] = False  # Set to True in production with HTTPS
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
```

### 2. Session Management Functions

Added helper functions for session management:

```python
def get_current_user():
    if 'user_id' in session:
        # Check if session has expired
        if 'session_created' in session:
            session_age = datetime.now() - datetime.fromisoformat(session['session_created'])
            if session_age > app.config['PERMANENT_SESSION_LIFETIME']:
                # Session expired, clear it
                session.clear()
                return None
        
        users = load_users()
        for user in users:
            if user['id'] == session['user_id']:
                return user
    return None

def refresh_session():
    """Refresh the session timestamp to prevent timeout"""
    session.permanent = True
    session['session_created'] = datetime.now().isoformat()
    session.modified = True

def check_session_timeout():
    """Check if the current session has timed out"""
    if 'session_created' not in session:
        return True
    
    try:
        session_created = datetime.fromisoformat(session['session_created'])
        session_age = datetime.now() - session_created
        return session_age > app.config['PERMANENT_SESSION_LIFETIME']
    except:
        return True
```

### 3. Enhanced Login/Registration

Updated login and registration functions to properly initialize sessions:

```python
# In login function
session.permanent = True  # Enable permanent sessions
session['user_id'] = authenticated_user['id']
session['session_created'] = datetime.now().isoformat()  # Track session creation time

# In register function
session.permanent = True  # Enable permanent sessions
session['user_id'] = new_user['id']
session['session_created'] = datetime.now().isoformat()  # Track session creation time
```

### 4. Protected Route Enhancement

Enhanced the `login_required` decorator with timeout checking:

```python
def login_required(f):
    def decorated_function(*args, **kwargs):
        # Check if user is logged in
        if 'user_id' not in session:
            flash('Please log in to access this page. Your session may have expired.', 'error')
            return redirect(url_for('login'))
        
        # Check session timeout
        if check_session_timeout():
            session.clear()
            flash('Your session has expired. Please log in again.', 'error')
            return redirect(url_for('login'))
        
        # Refresh session to prevent timeout
        refresh_session()
        
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function
```

### 5. API Endpoints for Session Management

Added API endpoints for client-side session management:

```python
@app.route('/api/session/refresh')
def api_session_refresh():
    """API endpoint to refresh session and prevent timeout"""
    if 'user_id' in session:
        refresh_session()
        return jsonify({
            'status': 'success',
            'message': 'Session refreshed',
            'session_expires_in': app.config['PERMANENT_SESSION_LIFETIME'].total_seconds()
        })
    else:
        return jsonify({
            'status': 'error',
            'message': 'Not logged in'
        }), 401

@app.route('/api/session/status')
def api_session_status():
    """API endpoint to check session status"""
    # Implementation details...
```

### 6. Client-Side Session Management

Added JavaScript to the base template for automatic session management:

- **Session Status Monitoring**: Checks session status every minute
- **Automatic Refresh**: Refreshes session every 10 minutes
- **Warning System**: Shows warnings 5 minutes before session expiry
- **User Activity Detection**: Refreshes session after user activity
- **Graceful Handling**: Proper handling of session expiration

```javascript
// Session Management
let sessionRefreshTimer = null;
let warningShown = false;

function checkSessionStatus() {
    fetch('/api/session/status')
        .then(response => response.json())
        .then(data => {
            if (!data.logged_in) {
                if (data.session_expired) {
                    showSessionExpiredAlert();
                }
                return;
            }
            
            // Show warning when 5 minutes left
            const warningTime = 5 * 60; // 5 minutes in seconds
            if (data.remaining_seconds <= warningTime && !warningShown) {
                showSessionWarning(data.remaining_seconds);
                warningShown = true;
            }
        })
        .catch(error => {
            console.error('Session check failed:', error);
        });
}
```

### 7. Booking Process Protection

Enhanced the booking route to handle session timeouts during booking:

```python
# Check if user is logged in
if 'user_id' in session:
    if check_session_timeout():
        session.clear()
        flash('Your session has expired. Please log in again to complete the booking.', 'error')
        return redirect(url_for('login'))
    
    # User is logged in - create booking directly
    # ... booking logic
```

## Benefits of the Solution

1. **Predictable Session Management**: 24-hour session timeout with clear configuration
2. **User-Friendly Warnings**: Users get warnings before sessions expire
3. **Automatic Recovery**: Sessions refresh automatically based on user activity
4. **Better Error Handling**: Clear error messages when sessions expire
5. **Booking Protection**: Booking processes are protected from session timeouts
6. **Client-Side Management**: JavaScript handles session management proactively

## Testing the Solution

To test the session timeout functionality:

1. **Login** to the application
2. **Navigate** through different pages
3. **Wait** for the session warning (5 minutes before expiry)
4. **Test** the "Extend Session" button functionality
5. **Verify** automatic redirects when session expires
6. **Check** that booking processes handle session timeouts gracefully

## Production Considerations

For production deployment:

1. **Set `SESSION_COOKIE_SECURE = True`** when using HTTPS
2. **Adjust timeout duration** based on business requirements
3. **Consider database-backed sessions** for better scalability
4. **Add rate limiting** to API endpoints
5. **Implement session analytics** for monitoring

## Files Modified

- `app.py` - Main application with session management
- `enhanced_app.py` - Enhanced application with additional features
- `templates/base.html` - Base template with JavaScript session management

This solution addresses the original issue where users would see retry buttons after periods of inactivity by implementing comprehensive session management that proactively prevents timeouts and gracefully handles them when they occur.