from flask import Flask, render_template, request, redirect, url_for, session, flash
import json
import os
import webbrowser
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date, timedelta
import uuid

app = Flask(__name__)
app.secret_key = 'your_secret_key_here_change_in_production'

# Session configuration
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=24)  # 24 hour session timeout
app.config['SESSION_COOKIE_SECURE'] = False  # Set to True in production with HTTPS
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

# Data file paths
USERS_FILE = 'data/users.json'
ROOMS_FILE = 'data/rooms.json'
HOTELS_FILE = 'data/hotels.json'
BOOKINGS_FILE = 'data/bookings.json'
COUPONS_FILE = 'data/coupons.json'
ACTIVITIES_FILE = 'data/activities.json'
ACTIVITY_BOOKINGS_FILE = 'data/activity_bookings.json'

# Ensure data directory exists
os.makedirs('data', exist_ok=True)

# Initialize JSON files if they don't exist
def init_json_files():
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'w') as f:
            json.dump([], f)
    
    if not os.path.exists(ROOMS_FILE):
        with open(ROOMS_FILE, 'w') as f:
            json.dump([], f)
    
    if not os.path.exists(BOOKINGS_FILE):
        with open(BOOKINGS_FILE, 'w') as f:
            json.dump([], f)

# Helper functions
def load_users():
    try:
        with open(USERS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_users(users):
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f, indent=4)

def load_rooms():
    try:
        with open(ROOMS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_rooms(rooms):
    with open(ROOMS_FILE, 'w') as f:
        json.dump(rooms, f, indent=4)

def load_bookings():
    try:
        with open(BOOKINGS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def load_hotels():
    try:
        with open(HOTELS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def load_enhanced_hotels():
    """Load hotels from enhanced_hotels.json if it exists, fallback to hotels.json"""
    enhanced_file = 'data/enhanced_hotels.json'
    try:
        if os.path.exists(enhanced_file):
            with open(enhanced_file, 'r') as f:
                return json.load(f)
        else:
            return load_hotels()
    except:
        return load_hotels()

def get_unified_room(room_id):
    """
    Unified function to find room by ID from either rooms.json or hotels.json
    Returns dict with room data and hotel info, or None if not found
    """
    # First try to find in rooms.json (legacy format)
    rooms = load_rooms()
    for room in rooms:
        if room['id'] == room_id:
            return {
                'room': room,
                'hotel': None,
                'source': 'rooms.json'
            }
    
    # Then try to find in hotels.json (current format)
    hotels = load_hotels()
    for hotel in hotels:
        if 'rooms' in hotel:
            for room in hotel['rooms']:
                if room.get('room_id') == room_id:
                    return {
                        'room': room,
                        'hotel': hotel,
                        'source': 'hotels.json'
                    }
    
    # Finally try enhanced_hotels.json
    enhanced_hotels = load_enhanced_hotels()
    for hotel in enhanced_hotels:
        if 'rooms' in hotel:
            for room in hotel['rooms']:
                if room.get('room_id') == room_id:
                    return {
                        'room': room,
                        'hotel': hotel,
                        'source': 'enhanced_hotels.json'
                    }
    
    return None

def get_room_availability(room_id, check_in, check_out):
    """
    Check if room is available for given dates
    Works with both room formats
    """
    room_data = get_unified_room(room_id)
    if not room_data:
        return False
    
    # For hotels.json format, check available_rooms
    if room_data['source'] in ['hotels.json', 'enhanced_hotels.json']:
        available_rooms = room_data['room'].get('available_rooms', 0)
        if available_rooms <= 0:
            return False
        # Also check existing bookings
        return is_room_available(room_id, check_in, check_out)
    
    # For rooms.json format, just check existing bookings
    return is_room_available(room_id, check_in, check_out)

def calculate_room_cost(room_data, check_in, check_out):
    """
    Calculate total cost for room booking
    Works with both room formats
    """
    room = room_data['room']
    price_per_night = room.get('price', 0)
    return calculate_total_cost(price_per_night, check_in, check_out)

def save_bookings(bookings):
    with open(BOOKINGS_FILE, 'w') as f:
        json.dump(bookings, f, indent=4)

def load_coupons():
    try:
        with open(COUPONS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_coupons(coupons):
    with open(COUPONS_FILE, 'w') as f:
        json.dump(coupons, f, indent=4)

def load_activities():
    try:
        with open(ACTIVITIES_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def load_activity_bookings():
    try:
        with open(ACTIVITY_BOOKINGS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_activity_bookings(activity_bookings):
    with open(ACTIVITY_BOOKINGS_FILE, 'w') as f:
        json.dump(activity_bookings, f, indent=4)

def get_current_user():
    if 'user_id' in session:
        # Check if session has expired
        if 'session_created' in session:
            session_age = datetime.now() - datetime.fromisoformat(session['session_created'])
            if session_age > app.config['PERMANENT_SESSION_LIFETIME']:
                # Session expired, clear it
                session.clear()
                return None
        
        users = load_users()
        for user in users:
            if user['id'] == session['user_id']:
                return user
    return None

def refresh_session():
    """Refresh the session timestamp to prevent timeout"""
    session.permanent = True
    session['session_created'] = datetime.now().isoformat()
    session.modified = True

def check_session_timeout():
    """Check if the current session has timed out"""
    if 'session_created' not in session:
        return True
    
    try:
        session_created = datetime.fromisoformat(session['session_created'])
        session_age = datetime.now() - session_created
        return session_age > app.config['PERMANENT_SESSION_LIFETIME']
    except:
        return True

def is_admin():
    user = get_current_user()
    return user and user.get('is_admin', False)

def login_required(f):
    def decorated_function(*args, **kwargs):
        # Check if user is logged in
        if 'user_id' not in session:
            flash('Please log in to access this page. Your session may have expired.', 'error')
            return redirect(url_for('login'))
        
        # Check session timeout
        if check_session_timeout():
            session.clear()
            flash('Your session has expired. Please log in again.', 'error')
            return redirect(url_for('login'))
        
        # Refresh session to prevent timeout
        refresh_session()
        
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

def admin_required(f):
    def decorated_function(*args, **kwargs):
        if not is_admin():
            flash('Admin access required.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

def is_room_available(room_id, check_in, check_out):
    bookings = load_bookings()
    check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()
    check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()
    
    for booking in bookings:
        if booking['room_id'] == room_id:
            booking_check_in = datetime.strptime(booking['check_in'], '%Y-%m-%d').date()
            booking_check_out = datetime.strptime(booking['check_out'], '%Y-%m-%d').date()
            
            # Check for overlap
            if (check_in_date < booking_check_out and check_out_date > booking_check_in):
                return False
    return True

def calculate_total_cost(price_per_night, check_in, check_out):
    check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()
    check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()
    nights = (check_out_date - check_in_date).days
    return price_per_night * nights

def validate_coupon(coupon_code, booking_amount):
    coupons = load_coupons()
    current_date = date.today()
    
    for coupon in coupons:
        if coupon['code'].upper() == coupon_code.upper():
            # Check if coupon is active
            if not coupon['active']:
                return {'valid': False, 'message': 'Coupon is not active'}
            
            # Check usage limit
            if coupon['used_count'] >= coupon['usage_limit']:
                return {'valid': False, 'message': 'Coupon usage limit reached'}
            
            # Check validity dates
            valid_from = datetime.strptime(coupon['valid_from'], '%Y-%m-%d').date()
            valid_until = datetime.strptime(coupon['valid_until'], '%Y-%m-%d').date()
            
            if current_date < valid_from:
                return {'valid': False, 'message': 'Coupon is not yet valid'}
            
            if current_date > valid_until:
                return {'valid': False, 'message': 'Coupon has expired'}
            
            # Check minimum amount
            if booking_amount < coupon['minimum_amount']:
                return {'valid': False, 'message': f'Minimum booking amount of ₹{coupon["minimum_amount"]} required'}
            
            return {'valid': True, 'coupon': coupon}
    
    return {'valid': False, 'message': 'Invalid coupon code'}

def apply_coupon_discount(booking_amount, coupon):
    if coupon['discount_type'] == 'percentage':
        discount = (booking_amount * coupon['discount_value']) / 100
    else:  # fixed amount
        discount = coupon['discount_value']
    
    # Ensure discount doesn't exceed booking amount
    discount = min(discount, booking_amount)
    final_amount = booking_amount - discount
    
    return {
        'original_amount': booking_amount,
        'discount': discount,
        'final_amount': final_amount,
        'discount_percentage': (discount / booking_amount) * 100 if booking_amount > 0 else 0
    }

def increment_coupon_usage(coupon_id):
    coupons = load_coupons()
    for coupon in coupons:
        if coupon['id'] == coupon_id:
            coupon['used_count'] += 1
            save_coupons(coupons)
            break

def get_recommended_activities(booking_amount=None):
    activities = load_activities()
    
    # Sort by rating
    recommended = sorted(activities, key=lambda x: x['rating'], reverse=True)
    
    # If booking amount is specified, recommend activities within reasonable budget
    if booking_amount:
        budget_limit = booking_amount * 0.5  # Activities should not exceed 50% of room cost
        recommended = [act for act in recommended if act['price'] <= budget_limit]
    
    return recommended[:4]  # Return top 4 recommendations

def get_location_suggestions():
    return {
        'hotel_location': {
            'name': 'Downtown Business District',
            'description': 'Prime location in the heart of the city',
            'nearby_attractions': [
                'City Mall (0.5 km)',
                'Central Park (1 km)',
                'Metro Station (0.2 km)',
                'Business Center (0.3 km)'
            ],
            'transportation': [
                'Metro: 2 minutes walk',
                'Bus Stop: 1 minute walk',
                'Taxi: Available 24/7',
                'Airport: 25 km (30 minutes)'
            ]
        },
        'recommended_hotels': [
            {
                'name': 'Grand Plaza Hotel',
                'rating': 4.6,
                'price_range': '₹3000-5000',
                'distance': '0.8 km',
                'highlights': ['Rooftop Restaurant', 'Business Center', 'Spa']
            },
            {
                'name': 'City Comfort Inn',
                'rating': 4.2,
                'price_range': '₹2000-3500',
                'distance': '1.2 km',
                'highlights': ['Free Breakfast', 'Gym', 'Parking']
            },
            {
                'name': 'Luxury Suites Downtown',
                'rating': 4.8,
                'price_range': '₹5000-8000',
                'distance': '0.5 km',
                'highlights': ['Concierge Service', 'Premium Spa', 'Fine Dining']
            }
        ]
    }

# Routes
@app.route('/')
def index():
    hotels = load_hotels()
    activities = load_activities()
    location_suggestions = get_location_suggestions()
    recommended_activities = get_recommended_activities()
    
    return render_template('index.html',
                         hotels=hotels,
                         user=get_current_user(),
                         activities=recommended_activities,
                         location_info=location_suggestions)

@app.route('/hotel/<hotel_id>')
def hotel_details(hotel_id):
    hotels = load_hotels()
    hotel = None
    for h in hotels:
        if h['id'] == hotel_id:
            hotel = h
            break
    
    if not hotel:
        flash('Hotel not found.', 'error')
        return redirect(url_for('index'))
    
    return render_template('hotel_details.html', hotel=hotel, user=get_current_user())

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        if password != confirm_password:
            flash('Passwords do not match.', 'error')
            return render_template('register.html')
        
        users = load_users()
        
        # Check if email already exists
        for user in users:
            if user['email'] == email:
                flash('Email already registered.', 'error')
                return render_template('register.html')
        
        # Create new user
        new_user = {
            'id': str(uuid.uuid4()),
            'name': name,
            'email': email,
            'password': generate_password_hash(password),
            'is_admin': len(users) == 0  # First user becomes admin
        }
        
        users.append(new_user)
        save_users(users)
        
        # Check if there's a pending guest booking
        if 'pending_booking' in session:
            pending_booking = session.pop('pending_booking')
            
            # Update the booking with the new user ID
            bookings = load_bookings()
            new_booking = {
                'id': str(uuid.uuid4()),
                'user_id': new_user['id'],
                'room_id': pending_booking['room_id'],
                'check_in': pending_booking['check_in'],
                'check_out': pending_booking['check_out'],
                'total_cost': pending_booking['total_cost'],
                'booking_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            bookings.append(new_booking)
            save_bookings(bookings)
            
            # Log in the user automatically
            session.permanent = True  # Enable permanent sessions
            session['user_id'] = new_user['id']
            session['session_created'] = datetime.now().isoformat()  # Track session creation time
            flash('Registration successful! Your booking has been completed.', 'success')
            
            if new_user.get('is_admin', False):
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('index'))
        else:
            flash('Registration successful. Please log in.', 'success')
            return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        users = load_users()
        
        for user in users:
            if user['email'] == email and check_password_hash(user['password'], password):
                session.permanent = True  # Enable permanent sessions
                session['user_id'] = user['id']
                session['session_created'] = datetime.now().isoformat()  # Track session creation time
                
                # Check if there's a pending guest booking
                if 'pending_booking' in session:
                    pending_booking = session.pop('pending_booking')
                    
                    # Create the actual booking
                    bookings = load_bookings()
                    new_booking = {
                        'id': str(uuid.uuid4()),
                        'user_id': user['id'],
                        'room_id': pending_booking['room_id'],
                        'check_in': pending_booking['check_in'],
                        'check_out': pending_booking['check_out'],
                        'total_cost': pending_booking['total_cost'],
                        'booking_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    }
                    
                    bookings.append(new_booking)
                    save_bookings(bookings)
                    
                    flash('Login successful! Your booking has been completed.', 'success')
                else:
                    flash('Login successful.', 'success')
                
                if user.get('is_admin', False):
                    return redirect(url_for('admin_dashboard'))
                else:
                    return redirect(url_for('index'))
        
        flash('Invalid email or password.', 'error')
        return render_template('login.html')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Logged out successfully.', 'success')
    return redirect(url_for('index'))

@app.route('/room/<room_id>')
def room_details(room_id):
    rooms = load_rooms()
    room = None
    for r in rooms:
        if r['id'] == room_id:
            room = r
            break
    
    if not room:
        flash('Room not found.', 'error')
        return redirect(url_for('index'))
    
    return render_template('room_details.html', room=room, user=get_current_user())

@app.route('/booking/<room_id>', methods=['GET', 'POST'])
def booking(room_id):
    # Use unified room lookup
    room_data = get_unified_room(room_id)
    
    if not room_data:
        flash('Room not found. Please select a room from our available options.', 'error')
        return redirect(url_for('index'))
    
    room = room_data['room']
    hotel = room_data['hotel']
    
    # Handle different room formats
    if room_data['source'] in ['hotels.json', 'enhanced_hotels.json']:
        # Hotel room format
        room_type = room.get('room_type', 'Room')
        capacity = room.get('capacity', '2 adults')
        size = room.get('size', '30 sqm')
        available_rooms = room.get('available_rooms', 0)
        amenities = room.get('amenities', [])
        description = room.get('description', '')
        images = room.get('images', [])
        room_price = room.get('price', 0)
        
        if hotel:
            hotel_name = hotel.get('name', 'Hotel')
            hotel_image = hotel.get('image', '')
            hotel_category = hotel.get('category', '')
            hotel_location = hotel.get('location', {})
        else:
            hotel_name = 'Hotel'
            hotel_image = ''
            hotel_category = ''
            hotel_location = {}
    else:
        # Legacy rooms.json format
        room_type = room.get('type', 'Room')
        capacity = '2 adults'  # Default
        size = '30 sqm'  # Default
        available_rooms = 1 if room.get('availability', True) else 0
        amenities = room.get('amenities', [])
        description = room.get('description', '')
        images = [room.get('image_path', '')]
        room_price = room.get('price', 0)
        
        hotel_name = room.get('name', 'Hotel').split(' - ')[0] if ' - ' in room.get('name', '') else 'Hotel'
        hotel_image = room.get('image_path', '')
        hotel_category = ''
        hotel_location = {}
    
    # Check if room is actually available
    if available_rooms <= 0:
        flash('This room is currently sold out. Please select another room.', 'error')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        check_in = request.form['check_in']
        check_out = request.form['check_out']
        guest_name = request.form.get('guest_name', '')
        guest_email = request.form.get('guest_email', '')
        
        # Enhanced date validation
        try:
            check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()
            check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()
            today = date.today()
            
            if check_in_date >= check_out_date:
                flash('Check-out date must be after check-in date.', 'error')
                return render_template('booking.html', 
                                     room_type=room_type, room_price=room_price, 
                                     hotel_name=hotel_name, hotel_image=hotel_image,
                                     capacity=capacity, size=size, amenities=amenities,
                                     description=description, images=images,
                                     available_rooms=available_rooms,
                                     guest_name=guest_name, guest_email=guest_email,
                                     user=get_current_user(), today=today.isoformat())
            
            if check_in_date < today:
                flash('Cannot book rooms in the past. Please select future dates.', 'error')
                return render_template('booking.html', 
                                     room_type=room_type, room_price=room_price, 
                                     hotel_name=hotel_name, hotel_image=hotel_image,
                                     capacity=capacity, size=size, amenities=amenities,
                                     description=description, images=images,
                                     available_rooms=available_rooms,
                                     guest_name=guest_name, guest_email=guest_email,
                                     user=get_current_user(), today=today.isoformat())
            
            # Check if check-out is too far in the future (reasonable limit)
            max_future_date = today + timedelta(days=365)
            if check_out_date > max_future_date:
                flash('Please select dates within one year from today.', 'error')
                return render_template('booking.html', 
                                     room_type=room_type, room_price=room_price, 
                                     hotel_name=hotel_name, hotel_image=hotel_image,
                                     capacity=capacity, size=size, amenities=amenities,
                                     description=description, images=images,
                                     available_rooms=available_rooms,
                                     guest_name=guest_name, guest_email=guest_email,
                                     user=get_current_user(), today=today.isoformat())
                                     
        except ValueError:
            flash('Invalid date format. Please use YYYY-MM-DD format.', 'error')
            return render_template('booking.html', 
                                 room_type=room_type, room_price=room_price, 
                                 hotel_name=hotel_name, hotel_image=hotel_image,
                                 capacity=capacity, size=size, amenities=amenities,
                                 description=description, images=images,
                                 available_rooms=available_rooms,
                                 guest_name=guest_name, guest_email=guest_email,
                                 user=get_current_user(), today=date.today().isoformat())
        
        # Check availability using unified function
        if not get_room_availability(room_id, check_in, check_out):
            flash('Room is not available for the selected dates. Please choose different dates.', 'error')
            return render_template('booking.html', 
                                 room_type=room_type, room_price=room_price, 
                                 hotel_name=hotel_name, hotel_image=hotel_image,
                                 capacity=capacity, size=size, amenities=amenities,
                                 description=description, images=images,
                                 available_rooms=available_rooms,
                                 guest_name=guest_name, guest_email=guest_email,
                                 user=get_current_user(), today=date.today().isoformat())
        
        # Calculate total cost using unified function
        total_cost = calculate_room_cost(room_data, check_in, check_out)
        coupon_code = request.form.get('coupon_code', '').strip()
        final_cost = total_cost
        coupon_applied = None
        discount_info = None
        
        # Apply coupon if provided
        if coupon_code:
            validation_result = validate_coupon(coupon_code, total_cost)
            if validation_result['valid']:
                coupon_applied = validation_result['coupon']
                discount_info = apply_coupon_discount(total_cost, coupon_applied)
                final_cost = discount_info['final_amount']
            else:
                flash(f'Coupon error: {validation_result["message"]}', 'error')
                return render_template('booking.html', 
                                     room_type=room_type, room_price=room_price, 
                                     hotel_name=hotel_name, hotel_image=hotel_image,
                                     capacity=capacity, size=size, amenities=amenities,
                                     description=description, images=images,
                                     available_rooms=available_rooms,
                                     guest_name=guest_name, guest_email=guest_email,
                                     coupon_code=coupon_code,
                                     user=get_current_user(), today=date.today().isoformat())
        
        # Check if user is logged in
        if 'user_id' in session:
            if check_session_timeout():
                session.clear()
                flash('Your session has expired. Please log in again to complete the booking.', 'error')
                return redirect(url_for('login'))
            
            # User is logged in - create booking directly
            bookings = load_bookings()
            new_booking = {
                'id': str(uuid.uuid4()),
                'user_id': session['user_id'],
                'room_id': room_id,
                'check_in': check_in,
                'check_out': check_out,
                'total_cost': final_cost,
                'original_cost': total_cost,
                'coupon_code': coupon_code if coupon_applied else None,
                'discount_amount': discount_info['discount'] if discount_info else 0,
                'booking_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'room_type': room_type,
                'hotel_name': hotel_name
            }
            
            bookings.append(new_booking)
            save_bookings(bookings)
            
            # Increment coupon usage if applied
            if coupon_applied:
                increment_coupon_usage(coupon_applied['id'])
                flash(f'🎉 Booking successful! Coupon "{coupon_code}" applied. You saved ₹{discount_info["discount"]:.0f}!', 'success')
            else:
                flash('🎉 Booking successful! Your reservation has been confirmed.', 'success')
            
            return redirect(url_for('user_dashboard'))
        else:
            # Guest user - store in session for now, require login to complete
            if not guest_name or not guest_email:
                flash('Please provide your name and email to continue with the booking.', 'error')
                return render_template('booking.html', 
                                     room_type=room_type, room_price=room_price, 
                                     hotel_name=hotel_name, hotel_image=hotel_image,
                                     capacity=capacity, size=size, amenities=amenities,
                                     description=description, images=images,
                                     available_rooms=available_rooms,
                                     guest_name=guest_name, guest_email=guest_email,
                                     coupon_code=coupon_code,
                                     user=get_current_user(), today=date.today().isoformat())
            
            # Store guest booking in session
            guest_booking = {
                'room_id': room_id,
                'check_in': check_in,
                'check_out': check_out,
                'total_cost': final_cost,
                'original_cost': total_cost,
                'coupon_code': coupon_code if coupon_applied else None,
                'discount_amount': discount_info['discount'] if discount_info else 0,
                'guest_name': guest_name,
                'guest_email': guest_email,
                'room_type': room_type,
                'hotel_name': hotel_name
            }
            
            session['pending_booking'] = guest_booking
            
            if coupon_applied:
                flash(f'Please log in or register to complete your booking. Coupon "{coupon_code}" will be applied! You\'ll save ₹{discount_info["discount"]:.0f}!', 'info')
            else:
                flash('Please log in or register to complete your booking. We\'ll hold your reservation for 15 minutes.', 'info')
            
            return redirect(url_for('login'))
    
    # GET request - show booking form
    today = date.today().isoformat()
    return render_template('booking.html', 
                         room_type=room_type, room_price=room_price, 
                         hotel_name=hotel_name, hotel_image=hotel_image,
                         capacity=capacity, size=size, amenities=amenities,
                         description=description, images=images,
                         available_rooms=available_rooms,
                         user=get_current_user(), today=today)

@app.route('/dashboard')
@login_required
def user_dashboard():
    user = get_current_user()
    bookings = load_bookings()
    activity_bookings = load_activity_bookings()
    rooms = load_rooms()
    activities = load_activities()
    
    # Get user's room bookings
    user_room_bookings = []
    for booking in bookings:
        if booking['user_id'] == user['id']:
            # Find room details
            for room in rooms:
                if room['id'] == booking['room_id']:
                    booking['room_name'] = room['name']
                    booking['room_type'] = room['type']
                    break
            user_room_bookings.append(booking)
    
    # Get user's activity bookings
    user_activity_bookings = []
    for activity_booking in activity_bookings:
        if activity_booking['user_id'] == user['id']:
            # Find activity details
            for activity in activities:
                if activity['id'] == activity_booking['activity_id']:
                    activity_booking['activity_category'] = activity['category']
                    activity_booking['activity_duration'] = activity['duration']
                    activity_booking['activity_location'] = activity['location']
                    activity_booking['activity_image'] = activity['image']
                    break
            user_activity_bookings.append(activity_booking)
    
    return render_template('user_dashboard.html', 
                         room_bookings=user_room_bookings, 
                         activity_bookings=user_activity_bookings, 
                         user=user)

@app.route('/activities')
def activities():
    activities = load_activities()
    return render_template('activities.html', activities=activities, user=get_current_user())

@app.route('/recommendations')
def recommendations_page():
    # Build simple hotel recommendations (score by rating + derived avg price)
    hotels = load_hotels()
    recommendations = []
    for hotel in hotels:
        # Normalize hotel data: some datasets use 'rooms' instead of 'room_types'
        room_types = hotel.get('room_types', hotel.get('rooms', []))
        hotel['room_types'] = room_types
        if room_types:
            avg_price = sum(rt.get('price', 0) for rt in room_types) / max(len(room_types), 1)
        else:
            avg_price = 0
        score = hotel.get('rating', 0) * 5
        hotel['avg_price'] = avg_price
        hotel['recommendation_score'] = score
        recommendations.append(hotel)

    recommendations.sort(key=lambda x: x.get('recommendation_score', 0), reverse=True)
    return render_template('recommendations.html', recommendations=recommendations, user=get_current_user())

@app.route('/my_bookings')
@login_required
def view_bookings():
    user = get_current_user()
    bookings = load_bookings()
    rooms = load_rooms()
    
    # Get user's bookings
    user_bookings = []
    for booking in bookings:
        if booking['user_id'] == user['id']:
            # Find room details
            for room in rooms:
                if room['id'] == booking['room_id']:
                    booking['room_name'] = room['name']
                    booking['room_type'] = room['type']
                    break
            user_bookings.append(booking)
    
    return render_template('my_bookings.html', bookings=user_bookings, user=user)

@app.route('/activity_booking/<activity_id>', methods=['GET', 'POST'])
@login_required
def activity_booking(activity_id):
    activities = load_activities()
    activity = None
    for a in activities:
        if a['id'] == activity_id:
            activity = a
            break
    
    if not activity:
        flash('Activity not found.', 'error')
        return redirect(url_for('activities'))
    
    if request.method == 'POST':
        activity_date = request.form['activity_date']
        participants = int(request.form['participants'])
        special_requests = request.form.get('special_requests', '')
        
        # Validate date
        try:
            activity_date_obj = datetime.strptime(activity_date, '%Y-%m-%d').date()
            if activity_date_obj < date.today():
                flash('Cannot book activities in the past.', 'error')
                return render_template('activity_booking.html', activity=activity)
        except ValueError:
            flash('Invalid date format.', 'error')
            return render_template('activity_booking.html', activity=activity)
        
        # Calculate total cost
        total_cost = activity['price'] * participants
        
        # Create activity booking
        activity_bookings = load_activity_bookings()
        new_activity_booking = {
            'id': str(uuid.uuid4()),
            'user_id': session['user_id'],
            'activity_id': activity_id,
            'activity_name': activity['name'],
            'activity_date': activity_date,
            'participants': participants,
            'total_cost': total_cost,
            'special_requests': special_requests,
            'booking_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'status': 'confirmed'
        }
        
        activity_bookings.append(new_activity_booking)
        save_activity_bookings(activity_bookings)
        
        flash('Activity booking successful!', 'success')
        return redirect(url_for('user_dashboard'))
    
    return render_template('activity_booking.html', activity=activity)

@app.route('/coupons')
def coupons():
    coupons = load_coupons()
    current_date = date.today()
    
    # Filter active and valid coupons
    active_coupons = []
    for coupon in coupons:
        if coupon['active']:
            valid_from = datetime.strptime(coupon['valid_from'], '%Y-%m-%d').date()
            valid_until = datetime.strptime(coupon['valid_until'], '%Y-%m-%d').date()
            if valid_from <= current_date <= valid_until and coupon['used_count'] < coupon['usage_limit']:
                active_coupons.append(coupon)
    
    return render_template('coupons.html', coupons=active_coupons, user=get_current_user())

@app.route('/location')
def location():
    location_info = get_location_suggestions()
    return render_template('location.html', location_info=location_info, user=get_current_user())

# Admin routes
@app.route('/admin')
@admin_required
def admin_dashboard():
    rooms = load_rooms()
    bookings = load_bookings()
    users = load_users()
    
    # Get recent bookings
    recent_bookings = sorted(bookings, key=lambda x: x['booking_date'], reverse=True)[:10]
    
    # Add room names to bookings
    for booking in recent_bookings:
        for room in rooms:
            if room['id'] == booking['room_id']:
                booking['room_name'] = room['name']
                break
    
    stats = {
        'total_rooms': len(rooms),
        'total_bookings': len(bookings),
        'total_users': len(users),
        'recent_bookings': recent_bookings
    }
    
    return render_template('admin_dashboard.html', stats=stats, user=get_current_user())

@app.route('/admin/add_room', methods=['GET', 'POST'])
@admin_required
def add_room():
    if request.method == 'POST':
        room_data = {
            'id': str(uuid.uuid4()),
            'name': request.form['name'],
            'type': request.form['type'],
            'ac': request.form.get('ac') == 'on',
            'price': float(request.form['price']),
            'image_path': request.form.get('image_path', 'static/images/default-room.jpg'),
            'availability': request.form.get('availability') == 'on'
        }
        
        rooms = load_rooms()
        rooms.append(room_data)
        save_rooms(rooms)
        
        flash('Room added successfully.', 'success')
        return redirect(url_for('admin_dashboard'))
    
    return render_template('admin_add_room.html')

@app.route('/admin/edit_room/<room_id>', methods=['GET', 'POST'])
@admin_required
def edit_room(room_id):
    rooms = load_rooms()
    room = None
    for r in rooms:
        if r['id'] == room_id:
            room = r
            break
    
    if not room:
        flash('Room not found.', 'error')
        return redirect(url_for('admin_dashboard'))
    
    if request.method == 'POST':
        room['name'] = request.form['name']
        room['type'] = request.form['type']
        room['ac'] = request.form.get('ac') == 'on'
        room['price'] = float(request.form['price'])
        room['image_path'] = request.form.get('image_path')
        room['availability'] = request.form.get('availability') == 'on'
        
        save_rooms(rooms)
        flash('Room updated successfully.', 'success')
        return redirect(url_for('admin_dashboard'))
    
    return render_template('admin_edit_room.html', room=room)

@app.route('/admin/delete_room/<room_id>')
@admin_required
def delete_room(room_id):
    rooms = load_rooms()
    rooms = [r for r in rooms if r['id'] != room_id]
    save_rooms(rooms)
    
    flash('Room deleted successfully.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/all_bookings')
@admin_required
def all_bookings():
    bookings = load_bookings()
    rooms = load_rooms()
    users = load_users()
    
    # Add room and user details to bookings
    for booking in bookings:
        for room in rooms:
            if room['id'] == booking['room_id']:
                booking['room_name'] = room['name']
                booking['room_type'] = room['type']
                break
        
        for user in users:
            if user['id'] == booking['user_id']:
                booking['user_name'] = user['name']
                booking['user_email'] = user['email']
                break
    
    return render_template('admin_all_bookings.html', bookings=bookings)

# Admin Coupon Management
@app.route('/admin/coupons')
@admin_required
def admin_coupons():
    coupons = load_coupons()
    return render_template('admin_coupons.html', coupons=coupons, user=get_current_user())

@app.route('/admin/add_coupon', methods=['GET', 'POST'])
@admin_required
def add_coupon():
    if request.method == 'POST':
        coupon_data = {
            'id': str(uuid.uuid4()),
            'code': request.form['code'].upper(),
            'description': request.form['description'],
            'discount_type': request.form['discount_type'],
            'discount_value': float(request.form['discount_value']),
            'minimum_amount': float(request.form['minimum_amount']),
            'valid_from': request.form['valid_from'],
            'valid_until': request.form['valid_until'],
            'usage_limit': int(request.form['usage_limit']),
            'used_count': 0,
            'active': request.form.get('active') == 'on'
        }
        
        coupons = load_coupons()
        coupons.append(coupon_data)
        save_coupons(coupons)
        
        flash('Coupon added successfully.', 'success')
        return redirect(url_for('admin_coupons'))
    
    return render_template('admin_add_coupon.html')

@app.route('/admin/edit_coupon/<coupon_id>', methods=['GET', 'POST'])
@admin_required
def edit_coupon(coupon_id):
    coupons = load_coupons()
    coupon = None
    for c in coupons:
        if c['id'] == coupon_id:
            coupon = c
            break
    
    if not coupon:
        flash('Coupon not found.', 'error')
        return redirect(url_for('admin_coupons'))
    
    if request.method == 'POST':
        coupon['code'] = request.form['code'].upper()
        coupon['description'] = request.form['description']
        coupon['discount_type'] = request.form['discount_type']
        coupon['discount_value'] = float(request.form['discount_value'])
        coupon['minimum_amount'] = float(request.form['minimum_amount'])
        coupon['valid_from'] = request.form['valid_from']
        coupon['valid_until'] = request.form['valid_until']
        coupon['usage_limit'] = int(request.form['usage_limit'])
        coupon['active'] = request.form.get('active') == 'on'
        
        save_coupons(coupons)
        flash('Coupon updated successfully.', 'success')
        return redirect(url_for('admin_coupons'))
    
    return render_template('admin_edit_coupon.html', coupon=coupon)

@app.route('/admin/delete_coupon/<coupon_id>')
@admin_required
def delete_coupon(coupon_id):
    coupons = load_coupons()
    coupons = [c for c in coupons if c['id'] != coupon_id]
    save_coupons(coupons)
    
    flash('Coupon deleted successfully.', 'success')
    return redirect(url_for('admin_coupons'))

# Admin Activity Management
@app.route('/admin/activities')
@admin_required
def admin_activities():
    activities = load_activities()
    return render_template('admin_activities.html', activities=activities, user=get_current_user())

@app.route('/admin/add_activity', methods=['GET', 'POST'])
@admin_required
def add_activity():
    if request.method == 'POST':
        activity_data = {
            'id': str(uuid.uuid4()),
            'name': request.form['name'],
            'description': request.form['description'],
            'category': request.form['category'],
            'duration': request.form['duration'],
            'price': float(request.form['price']),
            'location': request.form['location'],
            'image': request.form.get('image', 'https://images.unsplash.com/photo-1539650116574-75c0c6d73a0e?w=400&h=300&fit=crop'),
            'rating': float(request.form.get('rating', 4.0)),
            'included': request.form.get('included', '').split(',')
        }
        
        activities = load_activities()
        activities.append(activity_data)
        
        # Save activities to file
        with open(ACTIVITIES_FILE, 'w') as f:
            json.dump(activities, f, indent=4)
        
        flash('Activity added successfully.', 'success')
        return redirect(url_for('admin_activities'))
    
    return render_template('admin_add_activity.html')

@app.route('/admin/edit_activity/<activity_id>', methods=['GET', 'POST'])
@admin_required
def edit_activity(activity_id):
    activities = load_activities()
    activity = None
    for a in activities:
        if a['id'] == activity_id:
            activity = a
            break
    
    if not activity:
        flash('Activity not found.', 'error')
        return redirect(url_for('admin_activities'))
    
    if request.method == 'POST':
        activity['name'] = request.form['name']
        activity['description'] = request.form['description']
        activity['category'] = request.form['category']
        activity['duration'] = request.form['duration']
        activity['price'] = float(request.form['price'])
        activity['location'] = request.form['location']
        activity['image'] = request.form.get('image')
        activity['rating'] = float(request.form.get('rating', 4.0))
        activity['included'] = request.form.get('included', '').split(',')
        
        with open(ACTIVITIES_FILE, 'w') as f:
            json.dump(activities, f, indent=4)
        
        flash('Activity updated successfully.', 'success')
        return redirect(url_for('admin_activities'))
    
    return render_template('admin_edit_activity.html', activity=activity)

@app.route('/admin/delete_activity/<activity_id>')
@admin_required
def delete_activity(activity_id):
    activities = load_activities()
    activities = [a for a in activities if a['id'] != activity_id]
    
    with open(ACTIVITIES_FILE, 'w') as f:
        json.dump(activities, f, indent=4)
    
    flash('Activity deleted successfully.', 'success')
    return redirect(url_for('admin_activities'))

if __name__ == '__main__':
    init_json_files()
    
    print("Starting Hotel Booking Application...")
    print("Server running on http://127.0.0.1:8080")
    print("Please open your browser and go to http://127.0.0.1:8080")
    
    app.run(host="127.0.0.1", port=8080, debug=True)