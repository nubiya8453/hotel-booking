from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import json
import os
import webbrowser
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date, timedelta
import uuid

app = Flask(__name__)
app.secret_key = 'your_secret_key_here_change_in_production'

# Session configuration
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=24)  # 24 hour session timeout
app.config['SESSION_COOKIE_SECURE'] = False  # Set to True in production with HTTPS
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

# Data file paths
USERS_FILE = 'data/users.json'
HOTELS_FILE = 'data/enhanced_hotels.json'  # Using enhanced hotels
BOOKINGS_FILE = 'data/bookings.json'
COUPONS_FILE = 'data/coupons.json'
ACTIVITIES_FILE = 'data/activities.json'
ACTIVITY_BOOKINGS_FILE = 'data/activity_bookings.json'
PAYMENT_REPORTS_FILE = 'data/payment_reports.json'

# Ensure data directory exists
os.makedirs('data', exist_ok=True)

# Initialize JSON files if they don't exist
def init_json_files():
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'w') as f:
            json.dump([], f)
    
    if not os.path.exists(HOTELS_FILE):
        with open(HOTELS_FILE, 'w') as f:
            json.dump([], f)
    
    if not os.path.exists(BOOKINGS_FILE):
        with open(BOOKINGS_FILE, 'w') as f:
            json.dump([], f)
    
    if not os.path.exists(PAYMENT_REPORTS_FILE):
        with open(PAYMENT_REPORTS_FILE, 'w') as f:
            json.dump([], f)

# Helper functions
def load_users():
    try:
        with open(USERS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_users(users):
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f, indent=4)

def load_hotels():
    try:
        with open(HOTELS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_hotels(hotels):
    with open(HOTELS_FILE, 'w') as f:
        json.dump(hotels, f, indent=4)

def load_bookings():
    try:
        with open(BOOKINGS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_bookings(bookings):
    with open(BOOKINGS_FILE, 'w') as f:
        json.dump(bookings, f, indent=4)

def load_payment_reports():
    try:
        with open(PAYMENT_REPORTS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_payment_reports(reports):
    with open(PAYMENT_REPORTS_FILE, 'w') as f:
        json.dump(reports, f, indent=4)

def load_coupons():
    try:
        with open(COUPONS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_coupons(coupons):
    with open(COUPONS_FILE, 'w') as f:
        json.dump(coupons, f, indent=4)

def get_current_user():
    if 'user_id' in session:
        # Check if session has expired
        if 'session_created' in session:
            session_age = datetime.now() - datetime.fromisoformat(session['session_created'])
            if session_age > app.config['PERMANENT_SESSION_LIFETIME']:
                # Session expired, clear it
                session.clear()
                return None
        
        users = load_users()
        for user in users:
            if user['id'] == session['user_id']:
                return user
    return None

def refresh_session():
    """Refresh the session timestamp to prevent timeout"""
    session.permanent = True
    session['session_created'] = datetime.now().isoformat()
    session.modified = True

def check_session_timeout():
    """Check if the current session has timed out"""
    if 'session_created' not in session:
        return True
    
    try:
        session_created = datetime.fromisoformat(session['session_created'])
        session_age = datetime.now() - session_created
        return session_age > app.config['PERMANENT_SESSION_LIFETIME']
    except:
        return True

def is_admin():
    user = get_current_user()
    return user and user.get('is_admin', False)

def login_required(f):
    def decorated_function(*args, **kwargs):
        # Check if user is logged in
        if 'user_id' not in session:
            flash('Please log in to access this page. Your session may have expired.', 'error')
            return redirect(url_for('login'))
        
        # Check session timeout
        if check_session_timeout():
            session.clear()
            flash('Your session has expired. Please log in again.', 'error')
            return redirect(url_for('login'))
        
        # Refresh session to prevent timeout
        refresh_session()
        
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

def admin_required(f):
    def decorated_function(*args, **kwargs):
        if not is_admin():
            flash('Admin access required.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

def is_room_available(room_id, check_in, check_out, exclude_booking_id=None):
    """Return True if at least one room is available for the given date range.

    This counts existing overlapping bookings and compares against the room's
    `available_rooms` count so multiple bookings are allowed up to capacity.
    """
    bookings = load_bookings()
    check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()
    check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()

    # Count overlapping bookings for this room
    overlapping = 0
    for booking in bookings:
        # Skip if this is the booking we're updating (for edit functionality)
        if exclude_booking_id and booking.get('id') == exclude_booking_id:
            continue

        if booking.get('room_id') == room_id:
            try:
                booking_check_in = datetime.strptime(booking['check_in'], '%Y-%m-%d').date()
                booking_check_out = datetime.strptime(booking['check_out'], '%Y-%m-%d').date()
            except Exception:
                # ignore malformed bookings
                continue

            # Overlap check
            if (check_in_date < booking_check_out and check_out_date > booking_check_in):
                overlapping += 1

    # Get room available count
    hotel, room = get_hotel_by_room_id(room_id)
    if not room:
        return False

    room_capacity = room.get('available_rooms', 0)

    # If there are more rooms than overlapping bookings, there's availability
    return overlapping < room_capacity

def calculate_total_cost(price_per_night, check_in, check_out):
    check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()
    check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()
    nights = (check_out_date - check_in_date).days
    return price_per_night * nights

def calculate_booking_breakdown(price_per_night, check_in, check_out, coupon_code=None):
    """Calculate detailed booking cost breakdown"""
    check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()
    check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()
    total_nights = (check_out_date - check_in_date).days
    
    # Base calculation
    room_charges = price_per_night * total_nights
    taxes = room_charges * 0.18  # 18% GST
    service_charges = room_charges * 0.10  # 10% service charge
    subtotal = room_charges + taxes + service_charges
    
    breakdown = {
        'nights': total_nights,
        'price_per_night': price_per_night,
        'room_charges': room_charges,
        'taxes': taxes,
        'service_charges': service_charges,
        'subtotal': subtotal,
        'coupon_discount': 0,
        'final_amount': subtotal,
        'coupon_applied': False,
        'coupon_details': None
    }
    
    # Apply coupon if provided
    if coupon_code:
        validation_result = validate_coupon(coupon_code, subtotal)
        if validation_result['valid']:
            coupon = validation_result['coupon']
            if coupon['discount_type'] == 'percentage':
                discount = (subtotal * coupon['discount_value']) / 100
            else:  # fixed amount
                discount = coupon['discount_value']
            
            # Ensure discount doesn't exceed subtotal
            discount = min(discount, subtotal)
            final_amount = subtotal - discount
            
            breakdown.update({
                'coupon_applied': True,
                'coupon_details': coupon,
                'coupon_discount': discount,
                'final_amount': final_amount,
                'discount_percentage': (discount / subtotal) * 100 if subtotal > 0 else 0
            })
    
    return breakdown

def load_activities():
    try:
        with open(ACTIVITIES_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def validate_coupon(coupon_code, booking_amount):
    coupons = load_coupons()
    current_date = date.today()
    
    for coupon in coupons:
        if coupon['code'].upper() == coupon_code.upper():
            # Check if coupon is active
            if not coupon['active']:
                return {'valid': False, 'message': 'Coupon is not active'}
            
            # Check usage limit
            if coupon['used_count'] >= coupon['usage_limit']:
                return {'valid': False, 'message': 'Coupon usage limit reached'}
            
            # Check validity dates
            valid_from = datetime.strptime(coupon['valid_from'], '%Y-%m-%d').date()
            valid_until = datetime.strptime(coupon['valid_until'], '%Y-%m-%d').date()
            
            if current_date < valid_from:
                return {'valid': False, 'message': 'Coupon is not yet valid'}
            
            if current_date > valid_until:
                return {'valid': False, 'message': 'Coupon has expired'}
            
            # Check minimum amount
            if booking_amount < coupon['minimum_amount']:
                return {'valid': False, 'message': f'Minimum booking amount of ₹{coupon["minimum_amount"]} required'}
            
            return {'valid': True, 'coupon': coupon}
    
    return {'valid': False, 'message': 'Invalid coupon code'}

def increment_coupon_usage(coupon_id):
    coupons = load_coupons()
    for coupon in coupons:
        if coupon['id'] == coupon_id:
            coupon['used_count'] += 1
            save_coupons(coupons)
            break

def generate_payment_report(booking, hotel, room, user):
    """Generate detailed payment report"""
    report_id = str(uuid.uuid4())
    
    payment_methods = {
        'credit_card': {'name': 'Credit Card', 'processing_fee': 0, 'processing_time': 'Instant'},
        'debit_card': {'name': 'Debit Card', 'processing_fee': 0, 'processing_time': 'Instant'},
        'net_banking': {'name': 'Net Banking', 'processing_fee': 10, 'processing_time': '1-2 hours'},
        'upi': {'name': 'UPI', 'processing_fee': 0, 'processing_time': 'Instant'},
        'wallet': {'name': 'Digital Wallet', 'processing_fee': 5, 'processing_time': 'Instant'},
        'bank_transfer': {'name': 'Bank Transfer', 'processing_fee': 25, 'processing_time': '2-4 hours'}
    }
    
    payment_report = {
        'report_id': report_id,
        'booking_id': booking['id'],
        'user_id': user['id'],
        'user_name': user['name'],
        'user_email': user['email'],
        'hotel_name': hotel['hotel_name'],
        'room_type': room['room_type'],
        'room_id': room['room_id'],
        'check_in': booking['check_in'],
        'check_out': booking['check_out'],
        'booking_date': booking['booking_date'],
        'cost_breakdown': booking.get('cost_breakdown', {}),
        'payment_options': payment_methods,
        'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'status': 'pending_payment'
    }
    
    reports = load_payment_reports()
    reports.append(payment_report)
    save_payment_reports(reports)
    
    return payment_report

def get_hotel_by_room_id(room_id):
    """Find hotel containing the specified room"""
    hotels = load_hotels()
    for hotel in hotels:
        for room in hotel['rooms']:
            if room['room_id'] == room_id:
                return hotel, room
    return None, None


def get_remaining_rooms(room_id, check_in, check_out, exclude_booking_id=None):
    """Return the number of remaining rooms for the given date range."""
    bookings = load_bookings()
    try:
        check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()
        check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()
    except Exception:
        return 0

    overlapping = 0
    for booking in bookings:
        if exclude_booking_id and booking.get('id') == exclude_booking_id:
            continue
        if booking.get('room_id') != room_id:
            continue
        try:
            booking_check_in = datetime.strptime(booking['check_in'], '%Y-%m-%d').date()
            booking_check_out = datetime.strptime(booking['check_out'], '%Y-%m-%d').date()
        except Exception:
            continue
        if (check_in_date < booking_check_out and check_out_date > booking_check_in):
            overlapping += 1

    hotel, room = get_hotel_by_room_id(room_id)
    if not room:
        return 0

    capacity = room.get('available_rooms', 0)
    remaining = max(0, capacity - overlapping)
    return remaining

# Routes
@app.route('/')
def index():
    hotels = load_hotels()
    return render_template('enhanced_index.html', 
                         hotels=hotels, 
                         user=get_current_user())

@app.route('/hotel/<hotel_id>')
def hotel_details(hotel_id):
    hotels = load_hotels()
    hotel = None
    for h in hotels:
        if h['hotel_id'] == hotel_id:
            hotel = h
            break
    
    if not hotel:
        flash('Hotel not found.', 'error')
        return redirect(url_for('index'))
    
    return render_template('hotel_details.html', hotel=hotel, user=get_current_user())

@app.route('/room/<room_id>')
def room_details(room_id):
    hotel, room = get_hotel_by_room_id(room_id)
    
    if not hotel or not room:
        flash('Room not found.', 'error')
        return redirect(url_for('index'))
    
    return render_template('room_details.html', hotel=hotel, room=room, user=get_current_user())

@app.route('/booking/<room_id>', methods=['GET', 'POST'])
def booking(room_id):
    hotel, room = get_hotel_by_room_id(room_id)
    
    if not hotel or not room:
        flash('Room not found.', 'error')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        if request.method == 'POST':
            try:
                check_in = request.form['check_in']
                check_out = request.form['check_out']
                guest_name = request.form.get('guest_name', '')
                guest_email = request.form.get('guest_email', '')
                coupon_code = request.form.get('coupon_code', '').strip()
                payment_method = request.form.get('payment_method', 'credit_card')

                # Validate dates
                try:
                    check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()
                    check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()

                    if check_in_date >= check_out_date:
                        flash('Check-out date must be after check-in date.', 'error')
                        return render_template('booking.html', hotel=hotel, room=room, guest_name=guest_name, guest_email=guest_email, coupon_code=coupon_code)

                    if check_in_date < date.today():
                        flash('Cannot book rooms in the past.', 'error')
                        return render_template('booking.html', hotel=hotel, room=room, guest_name=guest_name, guest_email=guest_email, coupon_code=coupon_code)
                except ValueError:
                    flash('Invalid date format.', 'error')
                    return render_template('booking.html', hotel=hotel, room=room, guest_name=guest_name, guest_email=guest_email, coupon_code=coupon_code)

                # Check availability
                if not is_room_available(room_id, check_in, check_out):
                    remaining = get_remaining_rooms(room_id, check_in, check_out)
                    if remaining > 0:
                        flash(f'Only {remaining} room(s) left for the selected dates.', 'error')
                    else:
                        flash('Room is not available for the selected dates.', 'error')
                    return render_template('booking.html', hotel=hotel, room=room, guest_name=guest_name, guest_email=guest_email, coupon_code=coupon_code)

                # Calculate cost breakdown
                cost_breakdown = calculate_booking_breakdown(room['price'], check_in, check_out, coupon_code)

                # Check if user is logged in
                if 'user_id' in session:
                    if check_session_timeout():
                        session.clear()
                        flash('Your session has expired. Please log in again to complete the booking.', 'error')
                        return redirect(url_for('login'))
                    
                    user = get_current_user()
                    if not user:
                        session.clear()
                        flash('Session validation failed. Please log in again.', 'error')
                        return redirect(url_for('login'))

                    # Create booking
                    bookings = load_bookings()
                    new_booking = {
                        'id': str(uuid.uuid4()),
                        'user_id': user['id'],
                        'room_id': room_id,
                        'check_in': check_in,
                        'check_out': check_out,
                        'total_cost': cost_breakdown['final_amount'],
                        'original_cost': cost_breakdown['subtotal'],
                        'cost_breakdown': cost_breakdown,
                        'coupon_code': coupon_code if cost_breakdown['coupon_applied'] else None,
                        'payment_method': payment_method,
                        'booking_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        'status': 'confirmed'
                    }

                    bookings.append(new_booking)
                    save_bookings(bookings)

                    # Increment coupon usage if applied
                    if cost_breakdown['coupon_applied']:
                        increment_coupon_usage(cost_breakdown['coupon_details']['id'])
                        flash(f'Booking successful! Coupon "{coupon_code}" applied. You saved ₹{cost_breakdown["coupon_discount"]:.0f}!', 'success')
                    else:
                        flash('Booking successful!', 'success')

                    # Generate payment report
                    payment_report = generate_payment_report(new_booking, hotel, room, user)

                    # Decrement available_rooms for the booked room and persist
                    try:
                        hotels = load_hotels()
                        for h in hotels:
                            for r in h.get('rooms', []):
                                if r.get('room_id') == room_id:
                                    r['available_rooms'] = max(0, r.get('available_rooms', 0) - 1)
                                    save_hotels(hotels)
                                    break
                    except Exception:
                        app.logger.exception('Failed to decrement available_rooms for room %s', room_id)

                    return redirect(url_for('payment_receipt', report_id=payment_report['report_id']))
                else:
                    # Guest user - store in session for now, require login to complete
                    if not guest_name or not guest_email:
                        flash('Please provide your name and email to continue.', 'error')
                        return render_template('booking.html', hotel=hotel, room=room, guest_name=guest_name, guest_email=guest_email, coupon_code=coupon_code)

                    # Store guest booking in session
                    guest_booking = {
                        'room_id': room_id,
                        'hotel_name': hotel['hotel_name'],
                        'room_type': room['room_type'],
                        'check_in': check_in,
                        'check_out': check_out,
                        'cost_breakdown': cost_breakdown,
                        'guest_name': guest_name,
                        'guest_email': guest_email,
                        'payment_method': payment_method
                    }

                    session['pending_booking'] = guest_booking

                    if cost_breakdown['coupon_applied']:
                        flash(f'Please log in or register to complete your booking. Coupon "{coupon_code}" will be applied!', 'info')
                    else:
                        flash('Please log in or register to complete your booking.', 'info')

                    return redirect(url_for('login'))
            except Exception:
                app.logger.exception('Unexpected error during booking for room %s', room_id)
                flash('An unexpected error occurred while processing your booking. Please try again or contact support.', 'error')
                return render_template('booking.html', hotel=hotel, room=room)
    
    return render_template('booking.html', hotel=hotel, room=room)

@app.route('/payment_receipt/<report_id>')
def payment_receipt(report_id):
    reports = load_payment_reports()
    report = None
    for r in reports:
        if r['report_id'] == report_id:
            report = r
            break
    
    if not report:
        flash('Payment report not found.', 'error')
        return redirect(url_for('index'))
    
    user = get_current_user()
    if not user or user['id'] != report['user_id']:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('index'))
    
    return render_template('payment_receipt.html', report=report, user=user)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        if password != confirm_password:
            flash('Passwords do not match.', 'error')
            return render_template('register.html')
        
        users = load_users()
        
        # Check if email already exists
        for user in users:
            if user['email'] == email:
                flash('Email already registered.', 'error')
                return render_template('register.html')
        
        # Create new user
        new_user = {
            'id': str(uuid.uuid4()),
            'name': name,
            'email': email,
            'password': generate_password_hash(password),
            'is_admin': len(users) == 0  # First user becomes admin
        }
        
        users.append(new_user)
        save_users(users)
        
        # Check if there's a pending guest booking
        if 'pending_booking' in session:
            pending_booking = session.pop('pending_booking')
            
            # Create the actual booking
            bookings = load_bookings()
            new_booking = {
                'id': str(uuid.uuid4()),
                'user_id': new_user['id'],
                'room_id': pending_booking['room_id'],
                'check_in': pending_booking['check_in'],
                'check_out': pending_booking['check_out'],
                'total_cost': pending_booking['cost_breakdown']['final_amount'],
                'original_cost': pending_booking['cost_breakdown']['subtotal'],
                'cost_breakdown': pending_booking['cost_breakdown'],
                'coupon_code': pending_booking.get('coupon_code'),
                'payment_method': pending_booking.get('payment_method', 'credit_card'),
                'booking_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'status': 'confirmed'
            }
            
            bookings.append(new_booking)
            save_bookings(bookings)
            
            # Log in the user automatically
            session.permanent = True  # Enable permanent sessions
            session['user_id'] = new_user['id']
            session['session_created'] = datetime.now().isoformat()  # Track session creation time
            flash('Registration successful! Your booking has been completed.', 'success')
            
            # Generate payment report
            hotel, room = get_hotel_by_room_id(pending_booking['room_id'])
            if hotel and room:
                payment_report = generate_payment_report(new_booking, hotel, room, new_user)
                return redirect(url_for('payment_receipt', report_id=payment_report['report_id']))
            
            if new_user.get('is_admin', False):
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('index'))
        else:
            flash('Registration successful. Please log in.', 'success')
            return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        users = load_users()
        authenticated_user = None
        
        # Find user with matching email and verify password
        for user in users:
            try:
                if user.get('email') == email and 'password' in user:
                    if check_password_hash(user['password'], password):
                        authenticated_user = user
                        break
            except Exception:
                app.logger.exception('Error validating password for user: %s', user.get('email'))
                # Skip this user record if there's any issue with password hashing
                continue
        
        # If authentication successful
        if authenticated_user:
            session.permanent = True  # Enable permanent sessions
            session['user_id'] = authenticated_user['id']
            session['session_created'] = datetime.now().isoformat()  # Track session creation time
            
            # Check if there's a pending guest booking
            if 'pending_booking' in session:
                pending_booking = session.pop('pending_booking')
                
                # Create the actual booking
                bookings = load_bookings()
                new_booking = {
                    'id': str(uuid.uuid4()),
                    'user_id': authenticated_user['id'],
                    'room_id': pending_booking['room_id'],
                    'check_in': pending_booking['check_in'],
                    'check_out': pending_booking['check_out'],
                    'total_cost': pending_booking['cost_breakdown']['final_amount'],
                    'original_cost': pending_booking['cost_breakdown']['subtotal'],
                    'cost_breakdown': pending_booking['cost_breakdown'],
                    'coupon_code': pending_booking.get('coupon_code'),
                    'payment_method': pending_booking.get('payment_method', 'credit_card'),
                    'booking_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'status': 'confirmed'
                }
                
                bookings.append(new_booking)
                save_bookings(bookings)
                
                flash('Login successful! Your booking has been completed.', 'success')
                
                # Generate payment report
                hotel, room = get_hotel_by_room_id(pending_booking['room_id'])
                if hotel and room:
                    payment_report = generate_payment_report(new_booking, hotel, room, authenticated_user)
                    return redirect(url_for('payment_receipt', report_id=payment_report['report_id']))
            else:
                flash('Login successful.', 'success')
            
            # Redirect based on user type
            if authenticated_user.get('is_admin', False):
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('index'))
        else:
            flash('Invalid email or password.', 'error')
            return render_template('login.html')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Logged out successfully.', 'success')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def user_dashboard():
    user = get_current_user()
    bookings = load_bookings()
    reports = load_payment_reports()
    
    # Get user's bookings
    user_bookings = []
    user_reports = []
    for booking in bookings:
        if booking['user_id'] == user['id']:
            hotel, room = get_hotel_by_room_id(booking['room_id'])
            if hotel and room:
                booking['hotel_name'] = hotel['hotel_name']
                booking['room_type'] = room['room_type']
                booking['hotel_location'] = hotel['location']['area']
            user_bookings.append(booking)
    
    for report in reports:
        if report['user_id'] == user['id']:
            user_reports.append(report)
    
    return render_template('user_dashboard.html', 
                         bookings=user_bookings, 
                         reports=user_reports,
                         user=user)

@app.route('/location/<hotel_id>')
def hotel_location(hotel_id):
    hotels = load_hotels()
    hotel = None
    for h in hotels:
        if h['hotel_id'] == hotel_id:
            hotel = h
            break
    
    if not hotel:
        flash('Hotel not found.', 'error')
        return redirect(url_for('index'))
    
    return render_template('hotel_location.html', hotel=hotel, user=get_current_user())

@app.route('/api/hotels')
def api_hotels():
    """API endpoint for hotels data"""
    hotels = load_hotels()
    return jsonify(hotels)

@app.route('/api/session/refresh')
def api_session_refresh():
    """API endpoint to refresh session and prevent timeout"""
    if 'user_id' in session:
        refresh_session()
        return jsonify({
            'status': 'success',
            'message': 'Session refreshed',
            'session_expires_in': app.config['PERMANENT_SESSION_LIFETIME'].total_seconds()
        })
    else:
        return jsonify({
            'status': 'error',
            'message': 'Not logged in'
        }), 401

@app.route('/api/session/status')
def api_session_status():
    """API endpoint to check session status"""
    if 'user_id' not in session:
        return jsonify({
            'logged_in': False,
            'session_expired': False
        })
    
    session_expired = check_session_timeout()
    
    if session_expired:
        session.clear()
        return jsonify({
            'logged_in': False,
            'session_expired': True,
            'message': 'Session expired'
        })
    
    # Calculate remaining time
    if 'session_created' in session:
        try:
            session_created = datetime.fromisoformat(session['session_created'])
            session_age = datetime.now() - session_created
            remaining_time = app.config['PERMANENT_SESSION_LIFETIME'] - session_age
            remaining_seconds = max(0, remaining_time.total_seconds())
        except:
            remaining_seconds = 0
    else:
        remaining_seconds = 0
    
    return jsonify({
        'logged_in': True,
        'session_expired': False,
        'remaining_seconds': remaining_seconds,
        'timeout_hours': app.config['PERMANENT_SESSION_LIFETIME'].total_seconds() / 3600
    })
    """API endpoint for hotel search"""
    query = request.args.get('q', '').lower()
    area = request.args.get('area', '').lower()
    min_price = request.args.get('min_price', type=int)
    max_price = request.args.get('max_price', type=int)
    
    hotels = load_hotels()
    filtered_hotels = []
    
    for hotel in hotels:
        # Check name match
        name_match = query in hotel['hotel_name'].lower()
        
        # Check area match
        area_match = area in hotel['location']['area'].lower()
        
        # Check price range
        price_match = True
        if min_price is not None or max_price is not None:
            hotel_prices = [room['price'] for room in hotel['rooms']]
            min_hotel_price = min(hotel_prices)
            max_hotel_price = max(hotel_prices)
            
            if min_price is not None and max_hotel_price < min_price:
                price_match = False
            if max_price is not None and min_hotel_price > max_price:
                price_match = False
        
        if (name_match or not query) and (area_match or not area) and price_match:
            filtered_hotels.append(hotel)
    
    return jsonify(filtered_hotels)

# Admin routes
@app.route('/admin')
@admin_required
def admin_dashboard():
    hotels = load_hotels()
    bookings = load_bookings()
    users = load_users()
    reports = load_payment_reports()
    
    # Calculate statistics
    total_rooms = sum(len(hotel['rooms']) for hotel in hotels)
    total_bookings = len(bookings)
    total_revenue = sum(booking['total_cost'] for booking in bookings)
    active_users = len([user for user in users if not user.get('is_admin', False)])
    
    # Get recent bookings
    recent_bookings = sorted(bookings, key=lambda x: x['booking_date'], reverse=True)[:10]
    
    # Add room and hotel details to bookings
    for booking in recent_bookings:
        hotel, room = get_hotel_by_room_id(booking['room_id'])
        if hotel and room:
            booking['hotel_name'] = hotel['hotel_name']
            booking['room_type'] = room['room_type']
    
    stats = {
        'total_hotels': len(hotels),
        'total_rooms': total_rooms,
        'total_bookings': total_bookings,
        'total_revenue': total_revenue,
        'active_users': active_users,
        'recent_bookings': recent_bookings
    }
    
    return render_template('admin_dashboard.html', stats=stats, user=get_current_user())

@app.route('/activities')
def activities():
    """Display available activities"""
    # Load activities from data file (falls back to empty list)
    activities_data = load_activities()
    return render_template('activities.html', activities=activities_data, user=get_current_user())

@app.route('/recommendations')
def recommendations_page():
    """Display recommended activities and services"""
    # Build recommendations from available hotels so templates receive expected fields
    hotels = load_hotels()
    recommendations = []
    for h in hotels:
        room_types = []
        for r in h.get('rooms', []):
            room_types.append({'name': r.get('room_type', ''), 'price': r.get('price', 0)})

        score = int(min(100, (h.get('rating', 0) / 5.0) * 100))

        recommendations.append({
            'id': h.get('hotel_id'),
            'name': h.get('hotel_name'),
            'description': h.get('rooms', [{}])[0].get('description', '') if h.get('rooms') else '',
            'location': h.get('location', {}).get('area', ''),
            'image': h.get('image', ''),
            'rating': h.get('rating', 0),
            'recommendation_score': score,
            'room_types': room_types
        })

    # If no hotels available, fall back to a small static set
    if not recommendations:
        recommendations = [
            {'id': 'rec_001', 'name': 'Fine Dining Experience', 'description': 'Recommended restaurants near hotels', 'location': 'City center', 'image': '', 'rating': 4.5, 'recommendation_score': 85, 'room_types': []},
        ]

    return render_template('recommendations.html', recommendations=recommendations, user=get_current_user())

@app.route('/coupons')
def coupons():
    """Display available coupons and deals"""
    coupons_data = load_coupons()
    current_date = date.today()
    
    # Filter active and valid coupons
    active_coupons = []
    for coupon in coupons_data:
        if coupon['active']:
            valid_from = datetime.strptime(coupon['valid_from'], '%Y-%m-%d').date()
            valid_until = datetime.strptime(coupon['valid_until'], '%Y-%m-%d').date()
            if valid_from <= current_date <= valid_until and coupon['used_count'] < coupon['usage_limit']:
                active_coupons.append(coupon)
    
    return render_template('coupons.html', coupons=active_coupons, user=get_current_user())


@app.route('/admin/availability')
@admin_required
def admin_availability():
    """Return JSON with current room availability and overlapping bookings count."""
    hotels = load_hotels()
    bookings = load_bookings()

    report = []
    for h in hotels:
        for r in h.get('rooms', []):
            room_id = r.get('room_id')
            # compute number of overlapping bookings for all future dates (approx)
            overlapping = 0
            for b in bookings:
                if b.get('room_id') == room_id:
                    overlapping += 1
            report.append({
                'hotel_id': h.get('hotel_id'),
                'hotel_name': h.get('hotel_name'),
                'room_id': room_id,
                'room_type': r.get('room_type'),
                'available_rooms': r.get('available_rooms', 0),
                'bookings_count': overlapping
            })

    return jsonify(report)

@app.route('/location')
def location():
    """Display location information and suggestions"""
    location_info = {
        'hotel_location': {
            'name': 'Downtown Business District',
            'description': 'Prime location in the heart of the city',
            'nearby_attractions': [
                'City Mall (0.5 km)',
                'Central Park (1 km)',
                'Metro Station (0.2 km)',
                'Business Center (0.3 km)'
            ],
            'transportation': [
                'Metro: 2 minutes walk',
                'Bus Stop: 1 minute walk',
                'Taxi: Available 24/7',
                'Airport: 25 km (30 minutes)'
            ]
        },
        'recommended_hotels': [
            {
                'name': 'Grand Plaza Hotel',
                'rating': 4.6,
                'price_range': '₹3000-5000',
                'distance': '0.8 km',
                'highlights': ['Rooftop Restaurant', 'Business Center', 'Spa']
            },
            {
                'name': 'City Comfort Inn',
                'rating': 4.2,
                'price_range': '₹2000-3500',
                'distance': '1.2 km',
                'highlights': ['Free Breakfast', 'Gym', 'Parking']
            }
        ]
    }
    return render_template('location.html', location_info=location_info, user=get_current_user())

if __name__ == '__main__':
    init_json_files()
    
    print("Starting Enhanced Hotel Booking Application...")
    print("Server running on http://127.0.0.1:8080")
    print("Please open your browser and go to http://127.0.0.1:8080")
    
    app.run(host="127.0.0.1", port=8080, debug=True)