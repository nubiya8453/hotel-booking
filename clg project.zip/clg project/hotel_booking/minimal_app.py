#!/usr/bin/env python3
from flask import Flask, render_template_string, request, session, redirect, url_for, flash
import json
import os
import webbrowser
import time
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date
import uuid

app = Flask(__name__)
app.secret_key = 'hotel_booking_secret_key_2024'

# Data files
USERS_FILE = 'data/users.json'
ROOMS_FILE = 'data/rooms.json'
BOOKINGS_FILE = 'data/bookings.json'

# Ensure data directory exists
os.makedirs('data', exist_ok=True)

# Initialize data files
def init_files():
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'w') as f:
            json.dump([], f)
    
    if not os.path.exists(ROOMS_FILE):
        # Sample rooms
        sample_rooms = [
            {
                "id": "room001",
                "name": "Standard Room 101",
                "type": "Standard",
                "ac": False,
                "price": 1500,
                "image": "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=400&h=300&fit=crop",
                "availability": True
            },
            {
                "id": "room002", 
                "name": "Deluxe Room 201",
                "type": "Deluxe",
                "ac": True,
                "price": 2500,
                "image": "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&h=300&fit=crop",
                "availability": True
            },
            {
                "id": "room003",
                "name": "Premium Suite 301", 
                "type": "Premium",
                "ac": True,
                "price": 4500,
                "image": "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=400&h=300&fit=crop",
                "availability": True
            }
        ]
        with open(ROOMS_FILE, 'w') as f:
            json.dump(sample_rooms, f, indent=2)
    
    if not os.path.exists(BOOKINGS_FILE):
        with open(BOOKINGS_FILE, 'w') as f:
            json.dump([], f)

# Helper functions
def load_users():
    try:
        with open(USERS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_users(users):
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f, indent=2)

def load_rooms():
    try:
        with open(ROOMS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def load_bookings():
    try:
        with open(BOOKINGS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_bookings(bookings):
    with open(BOOKINGS_FILE, 'w') as f:
        json.dump(bookings, f, indent=2)

def get_current_user():
    if 'user_id' in session:
        users = load_users()
        for user in users:
            if user['id'] == session['user_id']:
                return user
    return None

@app.route('/')
def index():
    rooms = load_rooms()
    user = get_current_user()
    
    # Simple homepage template
    html_template = '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Hotel Booking System</title>
        <style>
            body { 
                font-family: Arial, sans-serif; 
                margin: 0; 
                padding: 20px;
                background-color: #f5f5f5;
            }
            .container { 
                max-width: 1200px; 
                margin: 0 auto; 
                background: white; 
                padding: 20px; 
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            .header {
                text-align: center;
                margin-bottom: 30px;
                padding-bottom: 20px;
                border-bottom: 2px solid #eee;
            }
            .nav {
                text-align: center;
                margin-bottom: 30px;
            }
            .nav a {
                margin: 0 10px;
                padding: 10px 20px;
                background: #007bff;
                color: white;
                text-decoration: none;
                border-radius: 5px;
            }
            .nav a:hover {
                background: #0056b3;
            }
            .rooms {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 20px;
                margin-top: 20px;
            }
            .room {
                border: 1px solid #ddd;
                border-radius: 10px;
                padding: 20px;
                text-align: center;
            }
            .room img {
                width: 100%;
                height: 200px;
                object-fit: cover;
                border-radius: 5px;
            }
            .room h3 {
                color: #333;
                margin: 15px 0 10px 0;
            }
            .price {
                color: #28a745;
                font-size: 24px;
                font-weight: bold;
                margin: 10px 0;
            }
            .book-btn {
                background: #28a745;
                color: white;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                text-decoration: none;
                display: inline-block;
                margin-top: 10px;
            }
            .book-btn:hover {
                background: #218838;
            }
            .ac-badge {
                background: #17a2b8;
                color: white;
                padding: 2px 8px;
                border-radius: 10px;
                font-size: 12px;
            }
            .success {
                background: #d4edda;
                color: #155724;
                padding: 10px;
                border-radius: 5px;
                margin: 10px 0;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🏨 Hotel Booking System</h1>
                <p>Welcome to our hotel booking platform</p>
            </div>
            
            <div class="nav">
                ''' + (f'''
                <span>Welcome, {user['name']}!</span>
                <a href="{url_for('user_dashboard')}">My Dashboard</a>
                <a href="{url_for('logout')}">Logout</a>
                ''' if user else '''
                <a href="{url_for('login')}">Login</a>
                <a href="{url_for('register')}">Register</a>
                ''') + '''
            </div>
            
            <h2>Available Rooms</h2>
            <div class="rooms">
                ''' + ''.join([f'''
                <div class="room">
                    <img src="{room['image']}" alt="{room['name']}" onerror="this.src='https://via.placeholder.com/400x300?text=Room+Image'">
                    <h3>{room['name']}</h3>
                    <p>Type: {room['type']}</p>
                    <p>Air Conditioning: {'<span class="ac-badge">AC</span>' if room['ac'] else 'No AC'}</p>
                    <div class="price">₹{room['price']} <small>/night</small></div>
                    <a href="{url_for('book_room', room_id=room['id'])}" class="book-btn">Book Now</a>
                </div>
                ''' for room in rooms]) + '''
            </div>
        </div>
    </body>
    </html>
    '''
    
    return html_template

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        
        users = load_users()
        
        # Check if email exists
        for user in users:
            if user['email'] == email:
                return "Email already registered! <a href='/register'>Try again</a>"
        
        # Create new user
        new_user = {
            'id': str(uuid.uuid4()),
            'name': name,
            'email': email,
            'password': generate_password_hash(password),
            'is_admin': len(users) == 0  # First user becomes admin
        }
        
        users.append(new_user)
        save_users(users)
        
        # Auto login
        session['user_id'] = new_user['id']
        
        return f'''
        <div style="text-align: center; padding: 50px;">
            <h2>Registration Successful!</h2>
            <p>Welcome, {name}!</p>
            <p>You are now logged in.</p>
            <a href="/" style="background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Go to Homepage</a>
        </div>
        '''
    
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Register</title>
        <style>
            body { font-family: Arial, sans-serif; padding: 50px; background: #f5f5f5; }
            .container { max-width: 400px; margin: 0 auto; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
            button { width: 100%; padding: 12px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; }
            button:hover { background: #0056b3; }
            h2 { text-align: center; margin-bottom: 30px; }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Register</h2>
            <form method="POST">
                <input type="text" name="name" placeholder="Full Name" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Register</button>
            </form>
            <p style="text-align: center; margin-top: 20px;">
                Already have an account? <a href="/login">Login here</a>
            </p>
        </div>
    </body>
    </html>
    '''

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        users = load_users()
        
        for user in users:
            if user['email'] == email and check_password_hash(user['password'], password):
                session['user_id'] = user['id']
                return '''
                <div style="text-align: center; padding: 50px;">
                    <h2>Login Successful!</h2>
                    <p>Welcome back, ''' + user['name'] + '''!</p>
                    <a href="/" style="background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Go to Homepage</a>
                </div>
                '''
        
        return "Invalid login! <a href='/login'>Try again</a>"
    
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Login</title>
        <style>
            body { font-family: Arial, sans-serif; padding: 50px; background: #f5f5f5; }
            .container { max-width: 400px; margin: 0 auto; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
            button { width: 100%; padding: 12px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; }
            button:hover { background: #0056b3; }
            h2 { text-align: center; margin-bottom: 30px; }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Login</h2>
            <form method="POST">
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
            <p style="text-align: center; margin-top: 20px;">
                Don't have an account? <a href="/register">Register here</a>
            </p>
        </div>
    </body>
    </html>
    '''

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return '''
    <div style="text-align: center; padding: 50px;">
        <h2>Logged Out Successfully</h2>
        <p>Thank you for using our hotel booking system!</p>
        <a href="/" style="background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Go to Homepage</a>
    </div>
    '''

@app.route('/book/<room_id>')
def book_room(room_id):
    rooms = load_rooms()
    room = None
    
    for r in rooms:
        if r['id'] == room_id:
            room = r
            break
    
    if not room:
        return "Room not found!"
    
    if request.method == 'POST':
        check_in = request.form['check_in']
        check_out = request.form['check_out']
        
        # Calculate cost
        try:
            check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()
            check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()
            nights = (check_out_date - check_in_date).days
            total_cost = nights * room['price']
        except:
            return "Invalid date format!"
        
        # Create booking
        if 'user_id' in session:
            bookings = load_bookings()
            new_booking = {
                'id': str(uuid.uuid4()),
                'user_id': session['user_id'],
                'room_id': room_id,
                'check_in': check_in,
                'check_out': check_out,
                'total_cost': total_cost,
                'booking_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            bookings.append(new_booking)
            save_bookings(bookings)
            
            return f'''
            <div style="text-align: center; padding: 50px;">
                <h2>Booking Successful!</h2>
                <p>Room: {room['name']}</p>
                <p>Check-in: {check_in}</p>
                <p>Check-out: {check_out}</p>
                <p>Total Cost: ₹{total_cost}</p>
                <a href="/dashboard" style="background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">View My Bookings</a>
            </div>
            '''
        else:
            return "Please <a href='/login'>login</a> to make a booking!"
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Book {room['name']}</title>
        <style>
            body {{ font-family: Arial, sans-serif; padding: 50px; background: #f5f5f5; }}
            .container {{ max-width: 600px; margin: 0 auto; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
            input {{ width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }}
            button {{ width: 100%; padding: 12px; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer; }}
            button:hover {{ background: #218838; }}
            h2 {{ text-align: center; margin-bottom: 30px; }}
            .room-info {{ background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Book {room['name']}</h2>
            
            <div class="room-info">
                <h3>{room['name']}</h3>
                <p>Type: {room['type']}</p>
                <p>Price: ₹{room['price']} per night</p>
                <p>Air Conditioning: {'Yes' if room['ac'] else 'No'}</p>
            </div>
            
            <form method="POST">
                <label>Check-in Date:</label>
                <input type="date" name="check_in" required min="{date.today()}">
                
                <label>Check-out Date:</label>
                <input type="date" name="check_out" required min="{date.today().strftime('%Y-%m-%d')}">
                
                <button type="submit">Confirm Booking</button>
            </form>
            
            <p style="text-align: center; margin-top: 20px;">
                <a href="/">Back to Rooms</a>
            </p>
        </div>
    </body>
    </html>
    '''

@app.route('/dashboard')
def dashboard():
    user = get_current_user()
    if not user:
        return "Please <a href='/login'>login</a> first!"
    
    bookings = load_bookings()
    rooms = load_rooms()
    
    user_bookings = []
    for booking in bookings:
        if booking['user_id'] == user['id']:
            # Find room details
            for room in rooms:
                if room['id'] == booking['room_id']:
                    booking['room_name'] = room['name']
                    break
            user_bookings.append(booking)
    
    booking_html = ''.join([f'''
    <div style="border: 1px solid #ddd; padding: 15px; margin: 10px 0; border-radius: 5px;">
        <h4>{booking.get('room_name', 'Unknown Room')}</h4>
        <p>Check-in: {booking['check_in']}</p>
        <p>Check-out: {booking['check_out']}</p>
        <p>Total Cost: ₹{booking['total_cost']}</p>
        <p>Booking Date: {booking['booking_date']}</p>
    </div>
    ''' for booking in user_bookings])
    
    if not booking_html:
        booking_html = '<p>No bookings yet. <a href="/">Book a room now!</a></p>'
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>My Dashboard</title>
        <style>
            body {{ font-family: Arial, sans-serif; padding: 50px; background: #f5f5f5; }}
            .container {{ max-width: 800px; margin: 0 auto; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
            h2 {{ text-align: center; margin-bottom: 30px; }}
            a {{ color: #007bff; text-decoration: none; }}
            a:hover {{ text-decoration: underline; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Welcome, {user['name']}!</h2>
            <p style="text-align: center;">
                <a href="/">← Back to Homepage</a> | 
                <a href="/logout">Logout</a>
            </p>
            
            <h3>My Bookings ({len(user_bookings)})</h3>
            {booking_html}
        </div>
    </body>
    </html>
    '''

if __name__ == '__main__':
    print("=" * 60)
    print("HOTEL BOOKING SYSTEM - MINIMAL VERSION")
    print("=" * 60)
    
    # Initialize data
    init_files()
    print("Data files initialized")
    print("Starting server on http://127.0.0.1:5000")
    print("Opening browser in 3 seconds...")
    
    time.sleep(3)
    
    try:
        webbrowser.open('http://127.0.0.1:5000')
        print("Browser opened!")
    except:
        print("Could not open browser automatically")
    
    print("Server running! Press Ctrl+C to stop.")
    print("Access at: http://127.0.0.1:5000")
    print("=" * 60)
    
    app.run(host="127.0.0.1", port=5000, debug=False)