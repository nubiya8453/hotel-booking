#!/usr/bin/env python3
"""
Simple Hotel Booking Application Runner
Starts the new universal hotel booking system on port 8081
"""

import sys
import os

# Add the current directory to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import and run the application
from simple_hotel_app import app

if __name__ == '__main__':
    print("=" * 60)
    print("🏨 SIMPLE HOTEL BOOKING APPLICATION")
    print("=" * 60)
    print("✅ Starting on http://127.0.0.1:8081")
    print("🌐 Access at: http://127.0.0.1:8081")
    print("📱 Mobile-friendly design")
    print("🎯 8 Hotels with different room types")
    print("💰 Price range: ₹2,800 - ₹18,000 per night")
    print("=" * 60)
    print("FEATURES:")
    print("• Simple hotel list with clickable selection")
    print("• Multiple room types per hotel")
    print("• Smart recommendations based on budget")
    print("• Date selection with availability")
    print("• Easy booking process")
    print("• Booking confirmation")
    print("=" * 60)
    print()
    
    try:
        app.run(host="127.0.0.1", port=8081, debug=True)
    except KeyboardInterrupt:
        print("\n👋 Application stopped by user")
    except Exception as e:
        print(f"❌ Error starting application: {e}")
    finally:
        print("🔚 Application closed")