from flask import Flask, render_template, request, redirect, url_for, session, flash
import json
import os
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date, timedelta
import uuid

app = Flask(__name__)
app.secret_key = 'your_secret_key_here_change_in_production'

# Data file paths
USERS_FILE = 'data/users.json'
ROOMS_FILE = 'data/rooms.json'
BOOKINGS_FILE = 'data/bookings.json'

# Ensure data directory exists
os.makedirs('data', exist_ok=True)

# Initialize JSON files if they don't exist
def init_json_files():
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'w') as f:
            json.dump([], f)
    
    if not os.path.exists(ROOMS_FILE):
        with open(ROOMS_FILE, 'w') as f:
            json.dump([], f)
    
    if not os.path.exists(BOOKINGS_FILE):
        with open(BOOKINGS_FILE, 'w') as f:
            json.dump([], f)

# Helper functions
def load_users():
    try:
        with open(USERS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_users(users):
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f, indent=4)

def load_rooms():
    try:
        with open(ROOMS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_rooms(rooms):
    with open(ROOMS_FILE, 'w') as f:
        json.dump(rooms, f, indent=4)

def load_bookings():
    try:
        with open(BOOKINGS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_bookings(bookings):
    with open(BOOKINGS_FILE, 'w') as f:
        json.dump(bookings, f, indent=4)

def get_current_user():
    if 'user_id' in session:
        users = load_users()
        for user in users:
            if user['id'] == session['user_id']:
                return user
    return None

def is_admin():
    user = get_current_user()
    return user and user.get('is_admin', False)

def login_required(f):
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

def admin_required(f):
    def decorated_function(*args, **kwargs):
        if not is_admin():
            flash('Admin access required.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

def is_room_available(room_id, check_in, check_out):
    bookings = load_bookings()
    check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()
    check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()
    
    for booking in bookings:
        if booking['room_id'] == room_id:
            booking_check_in = datetime.strptime(booking['check_in'], '%Y-%m-%d').date()
            booking_check_out = datetime.strptime(booking['check_out'], '%Y-%m-%d').date()
            
            # Check for overlap
            if (check_in_date < booking_check_out and check_out_date > booking_check_in):
                return False
    return True

def calculate_total_cost(price_per_night, check_in, check_out):
    check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()
    check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()
    nights = (check_out_date - check_in_date).days
    return price_per_night * nights

# Routes
@app.route('/')
def index():
    rooms = load_rooms()
    return render_template('index.html', rooms=rooms, user=get_current_user())

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        if password != confirm_password:
            flash('Passwords do not match.', 'error')
            return render_template('register.html')
        
        users = load_users()
        
        # Check if email already exists
        for user in users:
            if user['email'] == email:
                flash('Email already registered.', 'error')
                return render_template('register.html')
        
        # Create new user
        new_user = {
            'id': str(uuid.uuid4()),
            'name': name,
            'email': email,
            'password': generate_password_hash(password),
            'is_admin': len(users) == 0  # First user becomes admin
        }
        
        users.append(new_user)
        save_users(users)
        
        # Check if there's a pending guest booking
        if 'pending_booking' in session:
            pending_booking = session.pop('pending_booking')
            
            # Update the booking with the new user ID
            bookings = load_bookings()
            new_booking = {
                'id': str(uuid.uuid4()),
                'user_id': new_user['id'],
                'room_id': pending_booking['room_id'],
                'check_in': pending_booking['check_in'],
                'check_out': pending_booking['check_out'],
                'total_cost': pending_booking['total_cost'],
                'booking_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            bookings.append(new_booking)
            save_bookings(bookings)
            
            # Log in the user automatically
            session['user_id'] = new_user['id']
            flash('Registration successful! Your booking has been completed.', 'success')
            
            if new_user.get('is_admin', False):
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('index'))
        else:
            flash('Registration successful. Please log in.', 'success')
            return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        users = load_users()
        
        for user in users:
            if user['email'] == email and check_password_hash(user['password'], password):
                session['user_id'] = user['id']
                
                # Check if there's a pending guest booking
                if 'pending_booking' in session:
                    pending_booking = session.pop('pending_booking')
                    
                    # Create the actual booking
                    bookings = load_bookings()
                    new_booking = {
                        'id': str(uuid.uuid4()),
                        'user_id': user['id'],
                        'room_id': pending_booking['room_id'],
                        'check_in': pending_booking['check_in'],
                        'check_out': pending_booking['check_out'],
                        'total_cost': pending_booking['total_cost'],
                        'booking_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    }
                    
                    bookings.append(new_booking)
                    save_bookings(bookings)
                    
                    flash('Login successful! Your booking has been completed.', 'success')
                else:
                    flash('Login successful.', 'success')
                
                if user.get('is_admin', False):
                    return redirect(url_for('admin_dashboard'))
                else:
                    return redirect(url_for('index'))
        
        flash('Invalid email or password.', 'error')
        return render_template('login.html')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Logged out successfully.', 'success')
    return redirect(url_for('index'))

@app.route('/room/<room_id>')
def room_details(room_id):
    rooms = load_rooms()
    room = None
    for r in rooms:
        if r['id'] == room_id:
            room = r
            break
    
    if not room:
        flash('Room not found.', 'error')
        return redirect(url_for('index'))
    
    return render_template('room_details.html', room=room, user=get_current_user())

@app.route('/booking/<room_id>', methods=['GET', 'POST'])
def booking(room_id):
    rooms = load_rooms()
    room = None
    for r in rooms:
        if r['id'] == room_id:
            room = r
            break
    
    if not room:
        flash('Room not found.', 'error')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        check_in = request.form['check_in']
        check_out = request.form['check_out']
        guest_name = request.form.get('guest_name', '')
        guest_email = request.form.get('guest_email', '')
        
        # Validate dates
        try:
            check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()
            check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()
            
            if check_in_date >= check_out_date:
                flash('Check-out date must be after check-in date.', 'error')
                return render_template('booking.html', room=room, guest_name=guest_name, guest_email=guest_email)
            
            if check_in_date < date.today():
                flash('Cannot book rooms in the past.', 'error')
                return render_template('booking.html', room=room, guest_name=guest_name, guest_email=guest_email)
        except ValueError:
            flash('Invalid date format.', 'error')
            return render_template('booking.html', room=room, guest_name=guest_name, guest_email=guest_email)
        
        # Check availability
        if not is_room_available(room_id, check_in, check_out):
            flash('Room is not available for the selected dates.', 'error')
            return render_template('booking.html', room=room, guest_name=guest_name, guest_email=guest_email)
        
        # Calculate total cost
        total_cost = calculate_total_cost(room['price'], check_in, check_out)
        
        # Check if user is logged in
        if 'user_id' in session:
            # User is logged in - create booking directly
            bookings = load_bookings()
            new_booking = {
                'id': str(uuid.uuid4()),
                'user_id': session['user_id'],
                'room_id': room_id,
                'check_in': check_in,
                'check_out': check_out,
                'total_cost': total_cost,
                'booking_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            bookings.append(new_booking)
            save_bookings(bookings)
            
            flash('Booking successful!', 'success')
            return redirect(url_for('user_dashboard'))
        else:
            # Guest user - store in session for now, require login to complete
            if not guest_name or not guest_email:
                flash('Please provide your name and email to continue.', 'error')
                return render_template('booking.html', room=room, guest_name=guest_name, guest_email=guest_email)
            
            # Store guest booking in session
            guest_booking = {
                'room_id': room_id,
                'check_in': check_in,
                'check_out': check_out,
                'total_cost': total_cost,
                'guest_name': guest_name,
                'guest_email': guest_email,
                'room_name': room['name']
            }
            
            session['pending_booking'] = guest_booking
            flash('Please log in or register to complete your booking.', 'info')
            return redirect(url_for('login'))
    
    return render_template('booking.html', room=room)

@app.route('/dashboard')
@login_required
def user_dashboard():
    user = get_current_user()
    bookings = load_bookings()
    rooms = load_rooms()
    
    # Get user's bookings
    user_bookings = []
    for booking in bookings:
        if booking['user_id'] == user['id']:
            # Find room details
            for room in rooms:
                if room['id'] == booking['room_id']:
                    booking['room_name'] = room['name']
                    booking['room_type'] = room['type']
                    break
            user_bookings.append(booking)
    
    return render_template('user_dashboard.html', bookings=user_bookings, user=user)

# Admin routes
@app.route('/admin')
@admin_required
def admin_dashboard():
    rooms = load_rooms()
    bookings = load_bookings()
    users = load_users()
    
    # Get recent bookings
    recent_bookings = sorted(bookings, key=lambda x: x['booking_date'], reverse=True)[:10]
    
    # Add room names to bookings
    for booking in recent_bookings:
        for room in rooms:
            if room['id'] == booking['room_id']:
                booking['room_name'] = room['name']
                break
    
    stats = {
        'total_rooms': len(rooms),
        'total_bookings': len(bookings),
        'total_users': len(users),
        'recent_bookings': recent_bookings
    }
    
    return render_template('admin_dashboard.html', stats=stats, user=get_current_user())

@app.route('/admin/add_room', methods=['GET', 'POST'])
@admin_required
def add_room():
    if request.method == 'POST':
        room_data = {
            'id': str(uuid.uuid4()),
            'name': request.form['name'],
            'type': request.form['type'],
            'ac': request.form.get('ac') == 'on',
            'price': float(request.form['price']),
            'image_path': request.form.get('image_path', 'static/images/default-room.jpg'),
            'availability': request.form.get('availability') == 'on'
        }
        
        rooms = load_rooms()
        rooms.append(room_data)
        save_rooms(rooms)
        
        flash('Room added successfully.', 'success')
        return redirect(url_for('admin_dashboard'))
    
    return render_template('admin_add_room.html')

@app.route('/admin/edit_room/<room_id>', methods=['GET', 'POST'])
@admin_required
def edit_room(room_id):
    rooms = load_rooms()
    room = None
    for r in rooms:
        if r['id'] == room_id:
            room = r
            break
    
    if not room:
        flash('Room not found.', 'error')
        return redirect(url_for('admin_dashboard'))
    
    if request.method == 'POST':
        room['name'] = request.form['name']
        room['type'] = request.form['type']
        room['ac'] = request.form.get('ac') == 'on'
        room['price'] = float(request.form['price'])
        room['image_path'] = request.form.get('image_path')
        room['availability'] = request.form.get('availability') == 'on'
        
        save_rooms(rooms)
        flash('Room updated successfully.', 'success')
        return redirect(url_for('admin_dashboard'))
    
    return render_template('admin_edit_room.html', room=room)

@app.route('/admin/delete_room/<room_id>')
@admin_required
def delete_room(room_id):
    rooms = load_rooms()
    rooms = [r for r in rooms if r['id'] != room_id]
    save_rooms(rooms)
    
    flash('Room deleted successfully.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/all_bookings')
@admin_required
def all_bookings():
    bookings = load_bookings()
    rooms = load_rooms()
    users = load_users()
    
    # Add room and user details to bookings
    for booking in bookings:
        for room in rooms:
            if room['id'] == booking['room_id']:
                booking['room_name'] = room['name']
                booking['room_type'] = room['type']
                break
        
        for user in users:
            if user['id'] == booking['user_id']:
                booking['user_name'] = user['name']
                booking['user_email'] = user['email']
                break
    
    return render_template('admin_all_bookings.html', bookings=bookings)

if __name__ == '__main__':
    init_json_files()
    print("Starting Hotel Booking Application...")
    print("Application will be available at: http://127.0.0.1:5000")
    print("Press Ctrl+C to stop the server")
    app.run(host="127.0.0.1", port=5000, debug=True)