#!/usr/bin/env python3
from flask import Flask, request, session
import webbrowser
import time
from datetime import datetime
import json
import os

app = Flask(__name__)
app.secret_key = 'simple_hotel_secret'

print("=" * 50)
print("Starting Simple Hotel Booking System...")
print("=" * 50)

# Simple data storage
rooms_data = [
    {
        "id": "1",
        "name": "Standard Room",
        "price": 1500,
        "type": "Standard",
        "ac": False
    },
    {
        "id": "2", 
        "name": "Deluxe Room",
        "price": 2500,
        "type": "Deluxe",
        "ac": True
    },
    {
        "id": "3",
        "name": "Premium Suite",
        "price": 4500,
        "type": "Premium", 
        "ac": True
    }
]

@app.route('/')
def home():
    try:
        # Simple HTML template
        html = '''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Hotel Booking</title>
            <style>
                body { font-family: Arial; margin: 20px; background: #f0f0f0; }
                .container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; }
                .header { text-align: center; color: #333; margin-bottom: 30px; }
                .rooms { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
                .room { border: 1px solid #ddd; padding: 15px; border-radius: 8px; text-align: center; }
                .price { color: #28a745; font-size: 20px; font-weight: bold; margin: 10px 0; }
                .btn { background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px; }
                .btn:hover { background: #0056b3; }
                .nav { text-align: center; margin: 20px 0; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Simple Hotel Booking System</h1>
                    <p>Welcome to our hotel</p>
                </div>
                
                <div class="nav">
                    <a href="/login" class="btn">Login</a>
                    <a href="/register" class="btn">Register</a>
                    <a href="/bookings" class="btn">My Bookings</a>
                </div>
                
                <h2>Available Rooms</h2>
                <div class="rooms">
        '''
        
        # Add rooms
        for room in rooms_data:
            html += f'''
                    <div class="room">
                        <h3>{room["name"]}</h3>
                        <p>Type: {room["type"]}</p>
                        <p>AC: {"Yes" if room["ac"] else "No"}</p>
                        <div class="price">₹{room["price"]} per night</div>
                        <a href="/book/{room["id"]}" class="btn">Book Now</a>
                    </div>
            '''
        
        html += '''
                </div>
            </div>
        </body>
        </html>
        '''
        return html
    except Exception as e:
        return f"Error loading homepage: {str(e)}"

@app.route('/login')
def login():
    return '''
    <!DOCTYPE html>
    <html>
    <head><title>Login</title>
    <style>
        body { font-family: Arial; padding: 50px; background: #f0f0f0; }
        .container { max-width: 400px; margin: 0 auto; background: white; padding: 40px; border-radius: 10px; }
        input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
        button { width: 100%; padding: 12px; background: #007bff; color: white; border: none; border-radius: 5px; }
        h2 { text-align: center; }
    </style>
    </head>
    <body>
        <div class="container">
            <h2>Login</h2>
            <form action="/do_login" method="POST">
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
            <p style="text-align: center; margin-top: 20px;">
                <a href="/register">Don't have account? Register here</a>
            </p>
        </div>
    </body>
    </html>
    '''

@app.route('/do_login', methods=['POST'])
def do_login():
    email = request.form.get('email', '')
    password = request.form.get('password', '')
    
    # Simple demo login (accept any email/password)
    if email and password:
        session['user'] = email
        return '''
        <div style="text-align: center; padding: 50px;">
            <h2>Login Successful!</h2>
            <p>Welcome, ''' + email + '''!</p>
            <a href="/" style="background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Go to Homepage</a>
        </div>
        '''
    else:
        return "Login failed! <a href='/login'>Try again</a>"

@app.route('/register')
def register():
    return '''
    <!DOCTYPE html>
    <html>
    <head><title>Register</title>
    <style>
        body { font-family: Arial; padding: 50px; background: #f0f0f0; }
        .container { max-width: 400px; margin: 0 auto; background: white; padding: 40px; border-radius: 10px; }
        input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
        button { width: 100%; padding: 12px; background: #28a745; color: white; border: none; border-radius: 5px; }
        h2 { text-align: center; }
    </style>
    </head>
    <body>
        <div class="container">
            <h2>Register</h2>
            <form action="/do_register" method="POST">
                <input type="text" name="name" placeholder="Full Name" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Register</button>
            </form>
            <p style="text-align: center; margin-top: 20px;">
                <a href="/login">Already have account? Login here</a>
            </p>
        </div>
    </body>
    </html>
    '''

@app.route('/do_register', methods=['POST'])
def do_register():
    name = request.form.get('name', '')
    email = request.form.get('email', '')
    
    if name and email:
        session['user'] = email
        return '''
        <div style="text-align: center; padding: 50px;">
            <h2>Registration Successful!</h2>
            <p>Welcome, ''' + name + '''!</p>
            <a href="/" style="background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Go to Homepage</a>
        </div>
        '''
    else:
        return "Registration failed! <a href='/register'>Try again</a>"

@app.route('/bookings')
def bookings():
    user = session.get('user')
    if not user:
        return "Please <a href='/login'>login</a> first!"
    
    return '''
    <div style="text-align: center; padding: 50px;">
        <h2>My Bookings</h2>
        <p>Welcome, ''' + user + '''!</p>
        <p>No bookings yet. <a href="/">Book a room now!</a></p>
        <a href="/" style="background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Back to Homepage</a>
    </div>
    '''

@app.route('/book/<room_id>')
def book(room_id):
    user = session.get('user')
    if not user:
        return "Please <a href='/login'>login</a> first to book!"
    
    # Find room
    room = None
    for r in rooms_data:
        if r['id'] == room_id:
            room = r
            break
    
    if not room:
        return "Room not found! <a href='/'>Back to homepage</a>"
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head><title>Book {room["name"]}</title>
    <style>
        body {{ font-family: Arial; padding: 50px; background: #f0f0f0; }}
        .container {{ max-width: 500px; margin: 0 auto; background: white; padding: 40px; border-radius: 10px; }}
        input {{ width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }}
        button {{ width: 100%; padding: 12px; background: #28a745; color: white; border: none; border-radius: 5px; }}
        h2 {{ text-align: center; }}
        .room-info {{ background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }}
    </style>
    </head>
    <body>
        <div class="container">
            <h2>Book {room["name"]}</h2>
            
            <div class="room-info">
                <h3>{room["name"]}</h3>
                <p>Type: {room["type"]}</p>
                <p>Price: ₹{room["price"]} per night</p>
                <p>AC: {"Yes" if room["ac"] else "No"}</p>
            </div>
            
            <form action="/confirm_booking/{room_id}" method="POST">
                <input type="date" name="check_in" required min="{time.strftime('%Y-%m-%d')}">
                <input type="date" name="check_out" required min="{time.strftime('%Y-%m-%d')}">
                <button type="submit">Confirm Booking</button>
            </form>
            
            <p style="text-align: center; margin-top: 20px;">
                <a href="/">Back to Rooms</a>
            </p>
        </div>
    </body>
    </html>
    '''

@app.route('/confirm_booking/<room_id>', methods=['POST'])
def confirm_booking(room_id):
    user = session.get('user')
    if not user:
        return "Please login first!"
    
    check_in = request.form.get('check_in', '')
    check_out = request.form.get('check_out', '')
    
    # Find room
    room = None
    for r in rooms_data:
        if r['id'] == room_id:
            room = r
            break
    
    if not room:
        return "Room not found!"
    
    return f'''
    <div style="text-align: center; padding: 50px;">
        <h2>Booking Confirmed!</h2>
        <p>Room: {room["name"]}</p>
        <p>Check-in: {check_in}</p>
        <p>Check-out: {check_out}</p>
        <p>Price: ₹{room["price"]} per night</p>
        <p>Thank you for your booking!</p>
        <a href="/bookings" style="background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">View My Bookings</a>
    </div>
    '''

if __name__ == '__main__':
    print("Starting server on http://127.0.0.1:5000")
    print("Opening browser in 2 seconds...")
    
    time.sleep(2)
    
    try:
        webbrowser.open('http://127.0.0.1:5000')
        print("Browser opened!")
    except:
        print("Could not open browser automatically")
    
    print("Server running! Press Ctrl+C to stop.")
    print("Access at: http://127.0.0.1:5000")
    print("=" * 50)
    
    try:
        app.run(host="127.0.0.1", port=5000, debug=False)
    except Exception as e:
        print(f"Error starting server: {e}")
        input("Press Enter to exit...")