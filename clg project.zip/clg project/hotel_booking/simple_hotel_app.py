from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import json
import os
from datetime import datetime, date, timedelta
import uuid

app = Flask(__name__)
app.secret_key = 'simple_hotel_secret_key'

# Data file paths
HOTELS_FILE = 'data/universal_hotels.json'
BOOKINGS_FILE = 'data/simple_bookings.json'

# Ensure data directory exists
os.makedirs('data', exist_ok=True)

# Helper functions
def load_hotels():
    try:
        with open(HOTELS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_bookings(bookings):
    with open(BOOKINGS_FILE, 'w') as f:
        json.dump(bookings, f, indent=4)

def load_bookings():
    try:
        with open(BOOKINGS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def get_recommendations(check_in=None, check_out=None, budget=None, travelers=None):
    """Smart hotel recommendations based on user planning"""
    hotels = load_hotels()
    recommendations = []
    
    for hotel in hotels:
        # Calculate average price
        avg_price = sum(room['price'] for room in hotel['room_types']) / len(hotel['room_types'])
        
        # Score based on various factors
        score = 0
        
        # Budget matching
        if budget:
            if avg_price <= budget * 0.8:  # Under budget gets higher score
                score += 20
            elif avg_price <= budget:
                score += 15
            elif avg_price <= budget * 1.2:  # Slightly over budget
                score += 10
        
        # Rating score
        score += hotel['rating'] * 5
        
        # Location type matching
        location_type = hotel['location'].lower()
        if travelers and travelers >= 4:
            if 'family' in location_type or 'resort' in location_type:
                score += 15
        elif travelers and travelers == 2:
            if 'business' in location_type or 'city' in location_type:
                score += 10
            elif 'seaside' in location_type or 'boutique' in location_type:
                score += 15
        
        # Price range scoring
        if avg_price < 4000:
            score += 10  # Budget friendly
        elif avg_price < 7000:
            score += 8   # Mid-range
        else:
            score += 5   # Luxury
        
        hotel['avg_price'] = avg_price
        hotel['recommendation_score'] = score
        recommendations.append(hotel)
    
    # Sort by recommendation score
    recommendations.sort(key=lambda x: x['recommendation_score'], reverse=True)
    return recommendations

def calculate_nights(check_in, check_out):
    """Calculate number of nights"""
    try:
        check_in_date = datetime.strptime(check_in, '%Y-%m-%d').date()
        check_out_date = datetime.strptime(check_out, '%Y-%m-%d').date()
        return (check_out_date - check_in_date).days
    except:
        return 1

# Routes
@app.route('/')
def index():
    hotels = load_hotels()
    recommendations = get_recommendations()
    
    return render_template('simple_index.html', 
                         hotels=hotels, 
                         recommendations=recommendations[:5])  # Top 5 recommendations

@app.route('/search', methods=['POST'])
def search():
    check_in = request.form['check_in']
    check_out = request.form['check_out']
    budget = float(request.form.get('budget', 0))
    travelers = int(request.form.get('travelers', 2))
    
    # Calculate nights
    nights = calculate_nights(check_in, check_out)
    
    # Get recommendations
    recommendations = get_recommendations(check_in, check_out, budget, travelers)
    
    # Store search criteria in session for booking
    session['search_criteria'] = {
        'check_in': check_in,
        'check_out': check_out,
        'nights': nights,
        'budget': budget,
        'travelers': travelers
    }
    
    return render_template('search_results.html', 
                         hotels=recommendations,
                         search_criteria=session['search_criteria'])

@app.route('/hotel/<hotel_id>')
def hotel_details(hotel_id):
    hotels = load_hotels()
    hotel = None
    for h in hotels:
        if h['id'] == hotel_id:
            hotel = h
            break
    
    if not hotel:
        flash('Hotel not found.', 'error')
        return redirect(url_for('index'))
    
    search_criteria = session.get('search_criteria', {})
    nights = search_criteria.get('nights', 1)
    
    # Calculate total costs for each room type
    for room in hotel['room_types']:
        room['total_cost'] = room['price'] * nights
        room['nights'] = nights
    
    return render_template('hotel_detail_simple.html', 
                         hotel=hotel, 
                         search_criteria=search_criteria)

@app.route('/book/<hotel_id>/<room_id>', methods=['GET', 'POST'])
def book_room(hotel_id, room_id):
    hotels = load_hotels()
    hotel = None
    room = None
    
    for h in hotels:
        if h['id'] == hotel_id:
            hotel = h
            for r in h['room_types']:
                if r['id'] == room_id:
                    room = r
                    break
            break
    
    if not hotel or not room:
        flash('Hotel or room not found.', 'error')
        return redirect(url_for('index'))
    
    search_criteria = session.get('search_criteria', {})
    
    if request.method == 'POST':
        guest_name = request.form['guest_name']
        guest_email = request.form['guest_email']
        special_requests = request.form.get('special_requests', '')
        
        # Calculate total cost
        nights = search_criteria.get('nights', 1)
        total_cost = room['price'] * nights
        
        # Create booking
        booking = {
            'id': str(uuid.uuid4()),
            'hotel_id': hotel_id,
            'hotel_name': hotel['name'],
            'room_id': room_id,
            'room_name': room['name'],
            'guest_name': guest_name,
            'guest_email': guest_email,
            'check_in': search_criteria.get('check_in'),
            'check_out': search_criteria.get('check_out'),
            'nights': nights,
            'price_per_night': room['price'],
            'total_cost': total_cost,
            'special_requests': special_requests,
            'booking_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'status': 'confirmed'
        }
        
        # Save booking
        bookings = load_bookings()
        bookings.append(booking)
        save_bookings(bookings)
        
        return render_template('booking_confirmation.html', 
                             booking=booking, 
                             hotel=hotel, 
                             room=room)
    
    return render_template('booking_form.html', 
                         hotel=hotel, 
                         room=room, 
                         search_criteria=search_criteria)

@app.route('/bookings')
def view_bookings():
    bookings = load_bookings()
    return render_template('my_bookings.html', bookings=bookings)

@app.route('/recommendations')
def recommendations_page():
    recommendations = get_recommendations()
    return render_template('recommendations.html', recommendations=recommendations)

if __name__ == '__main__':
    print("Starting Simple Hotel Booking Application...")
    print("Server running on http://127.0.0.1:8081")
    print("Access at: http://127.0.0.1:8081")
    
    app.run(host="127.0.0.1", port=8081, debug=True)