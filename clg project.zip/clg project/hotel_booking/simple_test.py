#!/usr/bin/env python3
from flask import Flask, render_template_string
import webbrowser
import time

app = Flask(__name__)

@app.route('/')
def home():
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Simple Test</title>
        <style>
            body { 
                font-family: Arial, sans-serif; 
                text-align: center; 
                padding: 50px;
                background-color: #f0f0f0;
            }
            .container {
                background: white;
                padding: 40px;
                border-radius: 10px;
                box-shadow: 0 4px 15px rgba(0,0,0,0.1);
                max-width: 600px;
                margin: 0 auto;
            }
            .success {
                color: #28a745;
                font-size: 24px;
                margin-bottom: 20px;
            }
            .info {
                color: #666;
                font-size: 18px;
                margin-bottom: 20px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="success">✅ Flask is Working!</div>
            <div class="info">If you can see this, your Flask installation is working correctly.</div>
            <div class="info">Now let's test the full hotel booking application...</div>
            <p>Flask Server Time: ''' + time.strftime('%Y-%m-%d %H:%M:%S') + '''</p>
        </div>
    </body>
    </html>
    '''

if __name__ == '__main__':
    print("=" * 50)
    print("SIMPLE FLASK TEST")
    print("=" * 50)
    print("Testing Flask installation...")
    
    try:
        print("Flask version:", app.__class__.__module__)
        print("Starting server on http://127.0.0.1:5000")
        print("Opening browser in 2 seconds...")
        
        time.sleep(2)
        webbrowser.open('http://127.0.0.1:5000')
        
        print("Server running! Press Ctrl+C to stop.")
        app.run(host="127.0.0.1", port=5000, debug=False)
        
    except Exception as e:
        print(f"Error: {e}")
        print("Flask test failed!")
    finally:
        print("Test completed.")