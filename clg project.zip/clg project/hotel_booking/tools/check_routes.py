from simple_hotel_app import app

c = app.test_client()
paths = ['/', '/hotel/hotel_001', '/bookings', '/recommendations']

for p in paths:
    try:
        r = c.get(p)
        print(f"{p} -> {r.status_code}")
    except Exception as e:
        print(f"{p} -> ERROR: {e}")
