import importlib.util
from pathlib import Path

app_path = Path(__file__).parents[1] / 'app.py'
spec = importlib.util.spec_from_file_location('hotel_app', str(app_path))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
app = getattr(mod, 'app')

from flask import url_for

with app.test_request_context('/'):
    try:
        print('url_for view_bookings ->', url_for('view_bookings'))
    except Exception as e:
        print('Error building view_bookings:', type(e).__name__, e)
    try:
        print('url_for booking ->', url_for('booking', room_id='std_001'))
    except Exception as e:
        print('Error building booking:', type(e).__name__, e)
