import urllib.request, urllib.error

url = 'http://127.0.0.1:8080/activities'
req = urllib.request.Request(url, headers={'User-Agent':'debug-client/1.0'})
try:
    with urllib.request.urlopen(req, timeout=10) as resp:
        print('STATUS', resp.status)
        data = resp.read().decode('utf-8')
        print(data[:800])
except urllib.error.HTTPError as e:
    print('HTTPError', e.code)
    try:
        print(e.read().decode('utf-8')[:2000])
    except Exception as ex:
        print('Could not read body:', ex)
except Exception as e:
    print('Error', e)
