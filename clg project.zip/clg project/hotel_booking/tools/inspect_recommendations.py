import importlib.util
from pathlib import Path
import json

import os
app_path = Path(__file__).parents[1] / 'app.py'
os.chdir(str(Path(__file__).parents[1]))
spec = importlib.util.spec_from_file_location('hotel_app', str(app_path))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
load_hotels = getattr(mod, 'load_hotels')

hotels = load_hotels()
print('Total hotels loaded:', len(hotels))
for i, hotel in enumerate(hotels):
    has_room_types = isinstance(hotel.get('room_types'), list)
    rating = hotel.get('rating')
    print(i, 'id=', hotel.get('id'), 'name=', hotel.get('name') or hotel.get('hotel_name') , 'room_types=', 'ok' if has_room_types else 'MISSING', 'rating=', rating)
    # check inner structure
    if has_room_types:
        for rt in hotel.get('room_types', [])[:2]:
            print('   room type sample keys:', list(rt.keys()))
