import importlib.util
import sys
from pathlib import Path

app_path = Path(__file__).parents[1] / 'app.py'
spec = importlib.util.spec_from_file_location('hotel_app', str(app_path))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
app = getattr(mod, 'app')

print('Registered endpoints:')
for rule in sorted(app.url_map.iter_rules(), key=lambda r: r.rule):
    print(f"{rule.endpoint:30} {rule.rule}")
