from simple_hotel_app import app

print('Registered endpoints and rules:')
for rule in sorted(app.url_map.iter_rules(), key=lambda r: r.endpoint):
    methods = ','.join(sorted(rule.methods - {'HEAD','OPTIONS'}))
    print(f"{rule.endpoint}: {rule.rule} [{methods}]")
