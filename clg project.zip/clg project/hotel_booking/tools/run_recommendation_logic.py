import importlib.util
from pathlib import Path
import os

app_path = Path(__file__).parents[1] / 'app.py'
os.chdir(str(Path(__file__).parents[1]))
spec = importlib.util.spec_from_file_location('hotel_app', str(app_path))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
load_hotels = getattr(mod, 'load_hotels')

hotels = load_hotels()
recommendations = []
for hotel in hotels:
    room_types = hotel.get('room_types', [])
    if room_types:
        avg_price = sum(rt.get('price', 0) for rt in room_types) / max(len(room_types), 1)
    else:
        avg_price = 0
    score = hotel.get('rating', 0) * 5
    hotel['avg_price'] = avg_price
    hotel['recommendation_score'] = score
    recommendations.append(hotel)

print('First hotel keys:', list(recommendations[0].keys()))
print('recommendation_score for first hotel:', recommendations[0].get('recommendation_score'))
print('room_types key present?', 'room_types' in recommendations[0])
print('rooms key present?', 'rooms' in recommendations[0])
