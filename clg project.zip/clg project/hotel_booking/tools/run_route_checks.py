"""
Simple route checker for the Hotel Booking app.
Checks key routes on http://127.0.0.1:8081 and http://127.0.0.1:8080.
Run from the workspace root with: python hotel_booking\tools\run_route_checks.py
"""
import urllib.request
import urllib.error
import socket
import sys
import time

hosts = [("127.0.0.1", 8081), ("127.0.0.1", 8080)]
paths = ['/', '/hotel/hotel_001', '/bookings', '/recommendations']

print(f"Route check started: {time.strftime('%Y-%m-%d %H:%M:%S')}")
for host, port in hosts:
    base = f'http://{host}:{port}'
    print('\nChecking host:', base)
    for p in paths:
        url = base + p
        try:
            req = urllib.request.Request(url, headers={'User-Agent':'route-checker/1.0'})
            with urllib.request.urlopen(req, timeout=5) as resp:
                body = resp.read(2000)
                print(f"{url} -> {resp.status} {resp.reason}, {len(body)} bytes")
        except urllib.error.HTTPError as e:
            print(f"{url} -> HTTPError {e.code} {e.reason}")
        except urllib.error.URLError as e:
            # e.reason can be a socket error or string
            print(f"{url} -> URLError {e.reason}")
        except socket.timeout:
            print(f"{url} -> Timeout")
        except Exception as e:
            print(f"{url} -> Exception: {e}")

print('\nRoute check finished.')
sys.exit(0)
