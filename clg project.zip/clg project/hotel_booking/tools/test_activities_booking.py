"""
Test script: register a test user, log in, GET /activities, and POST a booking for a room.
Run with: python hotel_booking\tools\test_activities_booking.py
"""
import http.cookiejar, urllib.request, urllib.parse, json, sys

BASE = 'http://127.0.0.1:8080'
register_url = BASE + '/register'
login_url = BASE + '/login'
activities_url = BASE + '/activities'
booking_url = BASE + '/booking/std_001'  # using a known room id from data/rooms.json

cj = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
opener.addheaders = [('User-Agent', 'test-client/1.0')]

def post(url, data):
    data = urllib.parse.urlencode(data).encode()
    try:
        resp = opener.open(url, data=data, timeout=10)
        return resp.read().decode('utf-8'), resp.getcode(), resp.geturl()
    except urllib.error.HTTPError as e:
        return e.read().decode('utf-8'), e.code, e.geturl()
    except Exception as e:
        return str(e), None, url

print('Registering test user...')
body, code, final = post(register_url, {
    'name': 'Test User',
    'email': 'testuser+bot@example.com',
    'password': 'Password123!',
    'confirm_password': 'Password123!'
})
print('Register ->', code, final)

print('Logging in...')
body, code, final = post(login_url, {
    'email': 'testuser+bot@example.com',
    'password': 'Password123!'
})
print('Login ->', code, final)

print('\nRequesting activities page...')
try:
    resp = opener.open(activities_url, timeout=10)
    print('Activities GET ->', resp.getcode(), resp.geturl())
    snippet = resp.read(2000).decode('utf-8')
    print(snippet.split('\n')[:10])
except Exception as e:
    print('Activities GET error:', e)

print('\nAttempting booking (logged-in)...')
body, code, final = post(booking_url, {
    'check_in': '2025-12-25',
    'check_out': '2025-12-27',
    'guest_name': 'Test User',
    'guest_email': 'testuser+bot@example.com',
    # no coupon
})
print('Booking POST ->', code, final)
print('Response (first 800 chars):\n')
print(body[:800])
