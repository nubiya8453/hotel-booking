import importlib.util
from pathlib import Path
import os

app_path = Path(__file__).parents[1] / 'app.py'
os.chdir(str(Path(__file__).parents[1]))
spec = importlib.util.spec_from_file_location('hotel_app', str(app_path))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
app = getattr(mod, 'app')
load_hotels = getattr(mod, 'load_hotels')

hotels = load_hotels()
# Build recommendations like route
recommendations = []
for hotel in hotels:
    room_types = hotel.get('room_types', hotel.get('rooms', []))
    hotel['room_types'] = room_types
    avg_price = sum(rt.get('price', 0) for rt in room_types) / max(len(room_types), 1) if room_types else 0
    hotel['avg_price'] = avg_price
    hotel['recommendation_score'] = hotel.get('rating', 0) * 5
    recommendations.append(hotel)

print('Testing Jinja access for first hotel:')
with app.test_request_context('/'):
    template = app.jinja_env.from_string("{{ h.recommendation_score }}")
    try:
        out = template.render(h=recommendations[0])
        print('Rendered value:', out)
    except Exception as e:
        print('Jinja render error:', repr(e))

    # also try accessing in loop
    template2 = app.jinja_env.from_string("{% for x in recs %}{{ x.recommendation_score }}, {% endfor %}")
    try:
        out2 = template2.render(recs=recommendations)
        print('Loop render:', out2[:200])
    except Exception as e:
        print('Loop render error:', repr(e))
